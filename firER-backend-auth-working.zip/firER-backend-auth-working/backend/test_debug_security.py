#!/usr/bin/env python3
"""
Test script to verify debug endpoint security
This script tests that debug endpoints are properly disabled in production
"""

import os
import requests
import sys

def test_debug_endpoints():
    """Test debug endpoints with different environment settings"""
    
    base_url = "http://localhost:8000/api/debug"
    
    # Test endpoints
    endpoints = [
        "/orm-tables",
        "/orm-table-list", 
        "/environment"
    ]
    
    print("Testing Debug Endpoint Security")
    print("=" * 50)
    
    # Test with development environment (should work for admin)
    print("\n1. Testing with ENVIRONMENT=development")
    os.environ["ENVIRONMENT"] = "development"
    
    for endpoint in endpoints:
        url = f"{base_url}{endpoint}"
        try:
            # Note: This will fail with 401 unless you have valid admin credentials
            # But it should NOT return 404 in development
            response = requests.get(url)
            if response.status_code == 404:
                print(f"❌ {endpoint}: Unexpectedly disabled in development")
            elif response.status_code == 401:
                print(f"✅ {endpoint}: Available (401 = needs auth, expected)")
            else:
                print(f"✅ {endpoint}: Available (status: {response.status_code})")
        except requests.exceptions.ConnectionError:
            print(f"⚠️  {endpoint}: Server not running")
    
    # Test with production environment (should return 404)
    print("\n2. Testing with ENVIRONMENT=production")
    os.environ["ENVIRONMENT"] = "production"
    
    for endpoint in endpoints:
        url = f"{base_url}{endpoint}"
        try:
            response = requests.get(url)
            if response.status_code == 404:
                print(f"✅ {endpoint}: Properly disabled in production")
            else:
                print(f"❌ {endpoint}: Still accessible in production (status: {response.status_code})")
        except requests.exceptions.ConnectionError:
            print(f"⚠️  {endpoint}: Server not running")
    
    print("\n" + "=" * 50)
    print("Test completed. Restart the server to test production mode.")
    print("Set ENVIRONMENT=production in your environment variables.")

def check_environment_config():
    """Check current environment configuration"""
    
    current_env = os.getenv("ENVIRONMENT", "development")
    print(f"Current ENVIRONMENT: {current_env}")
    
    if current_env.lower() == "production":
        print("🔒 Production mode: Debug endpoints should be disabled")
    else:
        print("🔧 Development mode: Debug endpoints should be available")

if __name__ == "__main__":
    print("Debug Endpoint Security Test")
    print("=" * 30)
    
    check_environment_config()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        test_debug_endpoints()
    else:
        print("\nTo run endpoint tests, use: python test_debug_security.py --test")
        print("Note: Make sure the backend server is running first") 