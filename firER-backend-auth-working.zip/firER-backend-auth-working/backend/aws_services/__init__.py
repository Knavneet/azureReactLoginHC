# This file makes the aws_services directory a Python package
