/**
 * Security utilities for iframe and external content validation
 */

import { EXTERNAL_APPS, getEnabledExternalApps } from '../config';

// Generate allowed domains dynamically from enabled external apps
const generateAllowedDomains = (): string[] => {
  const enabledApps = getEnabledExternalApps();
  return enabledApps.map(app => {
    try {
      const url = new URL(app.baseUrl);
      return url.hostname;
    } catch (error) {
      console.warn(`Invalid URL for app ${app.id}: ${app.baseUrl}`);
      return '';
    }
  }).filter(domain => domain !== '');
};

// Dynamically generated whitelist of allowed domains for iframe content
export const getAllowedIframeDomains = (): string[] => {
  return generateAllowedDomains();
};

// Allowed protocols for external URLs
export const ALLOWED_PROTOCOLS = ['https:'] as const;

/**
 * Validates if a URL is safe to load in an iframe
 * @param url - The URL to validate
 * @returns boolean indicating if the URL is safe
 */
export const isValidIframeUrl = (url: string): boolean => {
  try {
    const urlObj = new URL(url);
    
    // Check protocol
    if (!ALLOWED_PROTOCOLS.includes(urlObj.protocol as any)) {
      console.warn(`Invalid protocol for iframe URL: ${urlObj.protocol}`);
      return false;
    }
    
    // Get dynamic allowed domains from enabled external apps
    const allowedDomains = getAllowedIframeDomains();
    
    // Check domain whitelist (fully dynamic based on enabled apps)
    const isAllowedDomain = allowedDomains.includes(urlObj.hostname);
    
    if (!isAllowedDomain) {
      console.warn(`Domain not in whitelist for iframe URL: ${urlObj.hostname}`);
      console.warn(`Allowed domains:`, allowedDomains);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Invalid URL format:', error);
    return false;
  }
};

/**
 * Validates if a URL belongs to a specific external app
 * @param url - The URL to validate
 * @param appId - The external app ID to check against
 * @returns boolean indicating if the URL belongs to the app
 */
export const isValidAppUrl = (url: string, appId: string): boolean => {
  const app = EXTERNAL_APPS[appId];
  if (!app || !app.enabled) {
    return false;
  }
  
  try {
    const urlObj = new URL(url);
    const appUrlObj = new URL(app.baseUrl);
    return urlObj.hostname === appUrlObj.hostname;
  } catch (error) {
    console.error('Invalid URL format:', error);
    return false;
  }
};

/**
 * Sanitizes iframe sandbox attributes based on security requirements
 * @param allowScripts - Whether to allow scripts (default: true for our use case)
 * @param allowForms - Whether to allow forms (default: true for our use case)
 * @returns string of sandbox attributes
 */
export const getSecureIframeSandbox = (
  allowScripts: boolean = true,
  allowForms: boolean = true
): string => {
  const attributes: string[] = [];
  
  // Never allow same-origin + scripts combination as it's dangerous
  // Never allow popups to prevent popup-based attacks
  
  if (allowScripts) {
    attributes.push('allow-scripts');
  }
  
  if (allowForms) {
    attributes.push('allow-forms');
  }
  
  // Note: 'allow-navigation' is not a valid sandbox flag
  // Valid navigation is handled by the browser by default when scripts are allowed
  
  return attributes.join(' ');
};

/**
 * Security configuration for different iframe types
 */
export const IFRAME_SECURITY_CONFIGS = {
  // For trusted IntelliOps services
  trusted: {
    sandbox: getSecureIframeSandbox(true, true),
    referrerPolicy: 'strict-origin-when-cross-origin' as const,
    loading: 'lazy' as const
  },
  
  // For less trusted external content (if needed in future)
  restricted: {
    sandbox: getSecureIframeSandbox(false, false),
    referrerPolicy: 'no-referrer' as const,
    loading: 'lazy' as const
  }
} as const; 