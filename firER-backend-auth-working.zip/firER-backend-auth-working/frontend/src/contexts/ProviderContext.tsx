import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { CloudProvider } from '../types';
import { API_BASE_URL } from '../config';
import { fetchWithAuth } from '../lib/api-utils';
import { configService } from '../lib/config-service';
import toast from 'react-hot-toast';

interface ProviderContextType {
  // State
  activeProvider: CloudProvider;
  availableProviders: Record<CloudProvider, boolean>;
  isLoading: boolean;
  hasAnyProviderAccess: boolean;
  
  // Actions
  changeProvider: (provider: CloudProvider) => Promise<void>;
  refreshProviderAccess: () => Promise<void>;
  
  // Provider names for display
  providerNames: Record<CloudProvider, string>;
}

const ProviderContext = createContext<ProviderContextType | undefined>(undefined);

interface ProviderProviderProps {
  children: React.ReactNode;
}

export function ProviderProvider({ children }: ProviderProviderProps) {
  const [activeProvider, setActiveProvider] = useState<CloudProvider>('aws');
  const [availableProviders, setAvailableProviders] = useState<Record<CloudProvider, boolean>>({
    aws: false,
    azure: false,
    gcp: false,
    onprem: false
  });
  const [isLoading, setIsLoading] = useState(true);
  const [hasAnyProviderAccess, setHasAnyProviderAccess] = useState(false);

  const providerNames: Record<CloudProvider, string> = {
    aws: 'Amazon Web Services',
    azure: 'Microsoft Azure',
    gcp: 'Google Cloud Platform',
    onprem: 'On-Premises Infrastructure'
  };

  // Load provider access from API
  const loadProviderAccess = useCallback(async () => {
    try {
      setIsLoading(true);
      
      // First, get the enabled providers from backend configuration
      const enabledProviders = await configService.getEnabledProviders();
      console.log('[ProviderContext] Enabled providers from backend:', enabledProviders);
      
      // Get current user from localStorage
      const currentUserStr = localStorage.getItem('currentUser');
      if (!currentUserStr) {
        console.warn('[ProviderContext] No current user found');
        setIsLoading(false);
        return;
      }

      const currentUser = JSON.parse(currentUserStr);
      if (!currentUser?.id) {
        console.warn('[ProviderContext] No user ID found');
        setIsLoading(false);
        return;
      }

      console.log('[ProviderContext] Loading provider access for user:', currentUser.id, 'is_admin:', currentUser.is_admin);

      // Fetch provider access from API for all users (including admins)
      // Admin status doesn't automatically grant provider access - it must be set via RBAC
      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      
      let response = await fetchWithAuth(`${apiUrl}/api/provider-access/user/${currentUser.id}`, {
        method: 'GET'
      });
      
      // Fallback to alternate endpoint if first fails
      if (!response.ok) {
        console.log('[ProviderContext] First API endpoint failed, trying alternate');
        response = await fetchWithAuth(`${apiUrl}/api/users/${currentUser.id}/provider-access`, {
          method: 'GET'
        });
      }

      if (response.ok) {
        const accessData = await response.json();
        console.log('[ProviderContext] Provider access data:', accessData);

        // Convert API response to UI format, but only include enabled providers
        const providerAccess = {
          aws: false,
          azure: false,
          gcp: false,
          onprem: false
        };

        if (Array.isArray(accessData)) {
          accessData.forEach((access: any) => {
            console.log('[ProviderContext] Processing access record:', access);
            if (access.provider && access.has_access === true && access.is_active === true) {
              const provider = access.provider as CloudProvider;
              
              // Only grant access if the provider is enabled in backend configuration
              if (enabledProviders.includes(provider)) {
                console.log('[ProviderContext] Granting access to enabled provider:', provider);
                if (provider in providerAccess) {
                  providerAccess[provider] = true;
                }
              } else {
                console.log('[ProviderContext] Provider access denied - provider not enabled in backend:', provider);
              }
            } else {
              console.log('[ProviderContext] Access denied for record:', access, 'Reasons: provider=', access.provider, 'has_access=', access.has_access, 'is_active=', access.is_active);
            }
          });
        }

        console.log('[ProviderContext] Processed provider access (filtered by enabled providers):', providerAccess);
        setAvailableProviders(providerAccess);

        // Check if user has any provider access
        const hasAccess = Object.values(providerAccess).some(access => access === true);
        setHasAnyProviderAccess(hasAccess);

        // Set active provider based on availability
        const savedProvider = localStorage.getItem('selectedProvider') as CloudProvider;
        
        if (savedProvider && providerAccess[savedProvider]) {
          // Use saved provider if it's available and enabled
          console.log('[ProviderContext] Using saved provider:', savedProvider);
          setActiveProvider(savedProvider);
        } else if (hasAccess) {
          // Find first available provider from enabled providers
          const firstAvailable = enabledProviders.find(provider => providerAccess[provider]);
          
          if (firstAvailable) {
            console.log('[ProviderContext] Setting first available enabled provider:', firstAvailable);
            setActiveProvider(firstAvailable);
            localStorage.setItem('selectedProvider', firstAvailable);
          }
        }

        // Update localStorage for other components
        try {
          const existingAccess = JSON.parse(localStorage.getItem('user_access') || '[]');
          let userExists = false;
          
          const updatedAccessList = existingAccess.map((access: any) => {
            const isCurrentUser = 
              (access.email && currentUser.email && access.email === currentUser.email) ||
              (access.userId && currentUser.id && (
                access.userId === currentUser.id || 
                access.userId === currentUser.id.toString()
              ));
              
            if (isCurrentUser) {
              userExists = true;
              return { ...access, providers: providerAccess };
            }
            return access;
          });
          
          if (!userExists) {
            updatedAccessList.push({
              userId: currentUser.id,
              id: currentUser.id,
              email: currentUser.email,
              userName: currentUser.name || currentUser.email,
              providers: providerAccess
            });
          }
          
          localStorage.setItem('user_access', JSON.stringify(updatedAccessList));
        } catch (error) {
          console.error('[ProviderContext] Error updating user_access:', error);
        }

      } else {
        console.warn('[ProviderContext] Failed to fetch provider access');
        setHasAnyProviderAccess(false);
      }
    } catch (error) {
      console.error('[ProviderContext] Error loading provider access:', error);
      setHasAnyProviderAccess(false);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Change active provider
  const changeProvider = useCallback(async (provider: CloudProvider) => {
    try {
      console.log('[ProviderContext] Changing provider to:', provider);
      
      // Validate provider access
      if (!availableProviders[provider]) {
        toast.error(`You don't have access to the ${providerNames[provider]} provider`);
        return;
      }

      // Update state
      setActiveProvider(provider);
      
      // Save to localStorage
      localStorage.setItem('selectedProvider', provider);
      
      // Dispatch global event for backward compatibility
      const event = new CustomEvent('providerChanged', { 
        detail: { provider },
        bubbles: true,
        cancelable: true
      });
      document.dispatchEvent(event);
      
      console.log('[ProviderContext] Provider changed successfully to:', provider);
      toast.success(`Switched to ${providerNames[provider]} provider`);
      
    } catch (error) {
      console.error('[ProviderContext] Error changing provider:', error);
      toast.error('Failed to change provider. Please try again.');
    }
  }, [availableProviders, providerNames]);

  // Refresh provider access
  const refreshProviderAccess = useCallback(async () => {
    await loadProviderAccess();
  }, [loadProviderAccess]);

  // Initialize provider access on mount
  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      loadProviderAccess();
    } else {
      setIsLoading(false);
    }
  }, [loadProviderAccess]);

  // Listen for localStorage changes to reload provider access when user data changes
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'currentUser' && e.newValue) {
        console.log('[ProviderContext] currentUser changed in localStorage, reloading provider access');
        loadProviderAccess();
      }
    };

    // Listen for custom login events
    const handleLoginEvent = () => {
      console.log('[ProviderContext] Login event received, reloading provider access');
      setTimeout(() => {
        loadProviderAccess();
      }, 100); // Small delay to ensure localStorage is updated
    };

    window.addEventListener('storage', handleStorageChange);
    document.addEventListener('userLoggedIn', handleLoginEvent);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      document.removeEventListener('userLoggedIn', handleLoginEvent);
    };
  }, [loadProviderAccess]);

  // Listen for user access changes
  useEffect(() => {
    const handleAccessChanged = (event: CustomEvent) => {
      console.log('[ProviderContext] Received userAccessChanged event');
      
      if (event.detail) {
        const { userId, email, providers } = event.detail;
        
        // Check if this affects the current user
        const currentUserStr = localStorage.getItem('currentUser');
        if (currentUserStr) {
          try {
            const currentUser = JSON.parse(currentUserStr);
            const isCurrentUser = 
              currentUser.email === email || 
              (currentUser.id && (currentUser.id.toString() === userId || currentUser.id === userId));
            
            if (isCurrentUser) {
              console.log('[ProviderContext] Current user access changed, updating providers');
              setAvailableProviders(providers);
              
              const hasAccess = Object.values(providers).some(access => access === true);
              setHasAnyProviderAccess(hasAccess);
              
              // Check if current provider is still available
              if (!providers[activeProvider] && hasAccess) {
                const firstAvailable = Object.entries(providers)
                  .find(([_, hasAccess]) => hasAccess === true)?.[0] as CloudProvider;
                  
                if (firstAvailable) {
                  changeProvider(firstAvailable);
                }
              }
              return;
            }
          } catch (e) {
            console.error('[ProviderContext] Error processing userAccessChanged event:', e);
          }
        }
      }
      
      // Fallback to reloading provider access
      loadProviderAccess();
    };
    
    document.addEventListener('userAccessChanged', handleAccessChanged as EventListener);
    
    return () => {
      document.removeEventListener('userAccessChanged', handleAccessChanged as EventListener);
    };
  }, [activeProvider, changeProvider, loadProviderAccess]);

  const value: ProviderContextType = {
    activeProvider,
    availableProviders,
    isLoading,
    hasAnyProviderAccess,
    changeProvider,
    refreshProviderAccess,
    providerNames
  };

  return (
    <ProviderContext.Provider value={value}>
      {children}
    </ProviderContext.Provider>
  );
}

export function useProvider(): ProviderContextType {
  const context = useContext(ProviderContext);
  if (context === undefined) {
    throw new Error('useProvider must be used within a ProviderProvider');
  }
  return context;
}
