import { API_BASE_URL } from '../config';
import { authService } from './auth-service';
import { CloudProvider } from '../types';

class ConfigService {
  private enabledProviders: CloudProvider[] | null = null;
  
  /**
   * Get the list of enabled providers from the backend
   */
  async getEnabledProviders(): Promise<CloudProvider[]> {
    // Return cached data if available
    if (this.enabledProviders !== null) {
      return this.enabledProviders;
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/config/enabled-providers`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include'
      });
      
      if (!response.ok) {
        console.error('Failed to fetch enabled providers:', response.status);
        // Fallback to all providers if API fails
        return ['aws', 'azure', 'gcp', 'onprem'];
      }
      
      const providers = await response.json();
      this.enabledProviders = providers as CloudProvider[];
      
      console.log('Enabled providers from backend:', this.enabledProviders);
      return this.enabledProviders;
    } catch (error) {
      console.error('Error fetching enabled providers:', error);
      // Fallback to all providers if API fails
      return ['aws', 'azure', 'gcp', 'onprem'];
    }
  }
  
  /**
   * Check if a specific provider is enabled
   */
  async isProviderEnabled(provider: CloudProvider): Promise<boolean> {
    const enabledProviders = await this.getEnabledProviders();
    return enabledProviders.includes(provider);
  }
  
  /**
   * Clear the cache to force a fresh fetch
   */
  clearCache(): void {
    this.enabledProviders = null;
  }
}

// Export a singleton instance
export const configService = new ConfigService(); 