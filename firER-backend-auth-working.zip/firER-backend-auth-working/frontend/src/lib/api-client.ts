/**
 * API Client for IntelliOps Backend
 * Handles all communication with the FastAPI backend
 * Updated to work with httpOnly cookies for secure authentication
 */

import axios from 'axios';
import { User } from '../types';
import { API_BASE_URL } from '../config';
import { toast } from 'react-hot-toast';
import { isAuthError } from './axios-interceptor';

// Configure Axios defaults
axios.defaults.baseURL = API_BASE_URL;
axios.defaults.withCredentials = true; // Important: include cookies

// Helper function to handle API errors
const handleApiError = (error: any) => {
  console.error('API Error:', error);
  
  // If it's an auth error, the interceptor will handle it
  if (isAuthError(error)) {
    return Promise.reject(error);
  }
  
  // Handle other types of errors
  const errorMessage = error.response?.data?.detail || 
                     error.response?.data?.message || 
                     error.message || 
                     'An error occurred. Please try again.';
  
  // Show error toast for non-auth errors
  toast.error(errorMessage, { duration: 5000 });
  
  return Promise.reject(error);
};

// Authentication API
export const authApi = {
  /**
   * Register a new user
   */
  async register(name: string, email: string, password: string) {
    try {
      const response = await axios.post('/api/auth/register', { 
        name, 
        email, 
        password 
      });
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Login a user
   */
  async login(email: string, password: string) {
    try {
      const formData = new URLSearchParams();
      formData.append('username', email);
      formData.append('password', password);
      
      const response = await axios.post('/api/auth/login', formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        validateStatus: (status) => status < 500 // Don't throw for 4xx errors
      });
      
      // If login was successful, return the response
      if (response.status >= 200 && response.status < 300) {
        return response.data;
      }
      
      // For 4xx errors, throw an error with the response data
      const error = new Error(response.data?.detail || 'Login failed');
      (error as any).response = response; // Attach response to error object
      throw error;
      
    } catch (error: any) {
      console.error('Login error:', error);
      
      // If it's a 401 error, handle it specifically
      if (error.response?.status === 401) {
        const errorMessage = error.response?.data?.detail || 'Incorrect email or password';
        const authError = new Error(errorMessage);
        (authError as any).response = error.response;
        throw authError;
      }
      
      // For other errors, use the standard error handling
      return handleApiError(error);
    }
  },
  
  /**
   * Logout user
   */
  async logout() {
    try {
      const response = await axios.post('/api/auth/logout');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Get current user profile
   */
  async getProfile() {
    try {
      const response = await axios.get('/api/users/me');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Update user profile
   */
  async updateProfile(userData: Partial<User>) {
    try {
      const response = await axios.put('/api/users/me', userData);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Change password
   */
  async changePassword(currentPassword: string, newPassword: string) {
    try {
      const response = await axios.put(
        '/api/users/me/password',
        { current_password: currentPassword, new_password: newPassword }
      );
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Refresh token
   */
  async refreshToken() {
    try {
      const response = await axios.post('/api/auth/refresh');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
};

// RBAC API
export const rbacApi = {
  /**
   * Get all roles (admin only)
   */
  async getRoles() {
    try {
      const response = await axios.get('/api/roles');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Create a new role (admin only)
   */
  async createRole(role: { name: string, description?: string }) {
    try {
      const response = await axios.post('/api/roles', role);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Get user roles
   */
  async getUserRoles(userId: number) {
    try {
      const response = await axios.get(`/api/user-roles/user/${userId}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Assign role to user (admin only)
   */
  async assignRole(userId: number, roleId: number) {
    try {
      const response = await axios.post(
        `/api/user-roles/`,
        { user_id: userId, role_id: roleId }
      );
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Remove role from user (admin only)
   */
  async removeRole(userId: number, userRoleId: number) {
    try {
      const response = await axios.delete(`/api/user-roles/${userRoleId}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Get provider access for a specific user (admin only)
   */
  async getUserProviderAccess(userId: number) {
    try {
      const response = await axios.get(`/api/provider-access/user/${userId}`);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Create provider access for a user (admin only)
   */
  async createProviderAccess(providerAccess: { user_id: number, provider: string, has_access: boolean, is_active: boolean }) {
    try {
      const response = await axios.post('/api/provider-access', providerAccess);
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Get provider access for a user
   */
  async getProviderAccess() {
    try {
      const response = await axios.get('/api/provider-access');
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  },
  
  /**
   * Update provider access (admin only)
   */
  async updateProviderAccess(userId: number, provider: string, hasAccess: boolean, isActive: boolean) {
    try {
      const response = await axios.put(
        `/api/provider-access/${provider}`,
        { has_access: hasAccess, is_active: isActive }
      );
      return response.data;
    } catch (error) {
      return handleApiError(error);
    }
  }
};
