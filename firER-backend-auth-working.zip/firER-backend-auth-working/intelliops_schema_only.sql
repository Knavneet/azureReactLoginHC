--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-08-20 10:18:19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 242 (class 1259 OID 17894)
-- Name: api_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_logs (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    log_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    session_id character varying(255),
    endpoint character varying(255),
    request_data json,
    response_data json,
    status_code integer,
    duration_ms integer,
    error_message text
);


ALTER TABLE public.api_logs OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 17893)
-- Name: api_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_logs_id_seq OWNER TO postgres;

--
-- TOC entry 5064 (class 0 OID 0)
-- Dependencies: 241
-- Name: api_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_logs_id_seq OWNED BY public.api_logs.id;


--
-- TOC entry 238 (class 1259 OID 17872)
-- Name: aws_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aws_settings (
    id integer NOT NULL,
    agent_id character varying(50) NOT NULL,
    agent_alias_id character varying(50) NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.aws_settings OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 17871)
-- Name: aws_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aws_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aws_settings_id_seq OWNER TO postgres;

--
-- TOC entry 5065 (class 0 OID 0)
-- Dependencies: 237
-- Name: aws_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aws_settings_id_seq OWNED BY public.aws_settings.id;


--
-- TOC entry 235 (class 1259 OID 17801)
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    thread_id integer,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.chat_messages OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 17800)
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO postgres;

--
-- TOC entry 5066 (class 0 OID 0)
-- Dependencies: 234
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- TOC entry 233 (class 1259 OID 17785)
-- Name: chat_threads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_threads (
    id integer NOT NULL,
    user_id integer,
    title character varying(255),
    cloud_provider character varying(32),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.chat_threads OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 17784)
-- Name: chat_threads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_threads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_threads_id_seq OWNER TO postgres;

--
-- TOC entry 5067 (class 0 OID 0)
-- Dependencies: 232
-- Name: chat_threads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_threads_id_seq OWNED BY public.chat_threads.id;


--
-- TOC entry 229 (class 1259 OID 17729)
-- Name: favorite_prompts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_prompts (
    id integer NOT NULL,
    user_id integer,
    prompt_id character varying(64),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.favorite_prompts OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 17728)
-- Name: favorite_prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_prompts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorite_prompts_id_seq OWNER TO postgres;

--
-- TOC entry 5068 (class 0 OID 0)
-- Dependencies: 228
-- Name: favorite_prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorite_prompts_id_seq OWNED BY public.favorite_prompts.id;


--
-- TOC entry 240 (class 1259 OID 17882)
-- Name: gcp_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gcp_settings (
    id integer NOT NULL,
    session_endpoint character varying(255) NOT NULL,
    agent_run_endpoint character varying(255) NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.gcp_settings OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 17881)
-- Name: gcp_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gcp_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gcp_settings_id_seq OWNER TO postgres;

--
-- TOC entry 5069 (class 0 OID 0)
-- Dependencies: 239
-- Name: gcp_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gcp_settings_id_seq OWNED BY public.gcp_settings.id;


--
-- TOC entry 236 (class 1259 OID 17831)
-- Name: navigation_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.navigation_items (
    id character varying(50) NOT NULL,
    title character varying(100) NOT NULL,
    path character varying(255) NOT NULL,
    tooltip character varying(255),
    "position" character varying(20) NOT NULL,
    "order" integer NOT NULL,
    is_enabled boolean,
    required_role character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.navigation_items OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 17710)
-- Name: prompts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prompts (
    id character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    category character varying(100),
    command text NOT NULL,
    cloud_provider character varying(32),
    user_id integer,
    is_system boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prompts OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 17692)
-- Name: provider_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_access (
    id integer NOT NULL,
    user_id integer,
    provider character varying(32) NOT NULL,
    has_access boolean DEFAULT true,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.provider_access OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 17691)
-- Name: provider_access_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provider_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.provider_access_id_seq OWNER TO postgres;

--
-- TOC entry 5070 (class 0 OID 0)
-- Dependencies: 225
-- Name: provider_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provider_access_id_seq OWNED BY public.provider_access.id;


--
-- TOC entry 231 (class 1259 OID 17751)
-- Name: provider_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_configs (
    id integer NOT NULL,
    user_id integer,
    provider character varying(32) NOT NULL,
    config jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.provider_configs OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 17750)
-- Name: provider_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provider_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.provider_configs_id_seq OWNER TO postgres;

--
-- TOC entry 5071 (class 0 OID 0)
-- Dependencies: 230
-- Name: provider_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provider_configs_id_seq OWNED BY public.provider_configs.id;


--
-- TOC entry 224 (class 1259 OID 17659)
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role_id integer,
    permission character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 17658)
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_permissions_id_seq OWNER TO postgres;

--
-- TOC entry 5072 (class 0 OID 0)
-- Dependencies: 223
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- TOC entry 220 (class 1259 OID 17625)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 17624)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- TOC entry 5073 (class 0 OID 0)
-- Dependencies: 219
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 222 (class 1259 OID 17637)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 17636)
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO postgres;

--
-- TOC entry 5074 (class 0 OID 0)
-- Dependencies: 221
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- TOC entry 218 (class 1259 OID 17611)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    hashed_password character varying(128) NOT NULL,
    is_admin boolean DEFAULT false,
    is_authenticated boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 17610)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 5075 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4841 (class 2604 OID 17897)
-- Name: api_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_logs ALTER COLUMN id SET DEFAULT nextval('public.api_logs_id_seq'::regclass);


--
-- TOC entry 4835 (class 2604 OID 17875)
-- Name: aws_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aws_settings ALTER COLUMN id SET DEFAULT nextval('public.aws_settings_id_seq'::regclass);


--
-- TOC entry 4831 (class 2604 OID 17804)
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- TOC entry 4828 (class 2604 OID 17788)
-- Name: chat_threads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_threads ALTER COLUMN id SET DEFAULT nextval('public.chat_threads_id_seq'::regclass);


--
-- TOC entry 4824 (class 2604 OID 17732)
-- Name: favorite_prompts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_prompts ALTER COLUMN id SET DEFAULT nextval('public.favorite_prompts_id_seq'::regclass);


--
-- TOC entry 4838 (class 2604 OID 17885)
-- Name: gcp_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gcp_settings ALTER COLUMN id SET DEFAULT nextval('public.gcp_settings_id_seq'::regclass);


--
-- TOC entry 4817 (class 2604 OID 17695)
-- Name: provider_access id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_access ALTER COLUMN id SET DEFAULT nextval('public.provider_access_id_seq'::regclass);


--
-- TOC entry 4826 (class 2604 OID 17754)
-- Name: provider_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_configs ALTER COLUMN id SET DEFAULT nextval('public.provider_configs_id_seq'::regclass);


--
-- TOC entry 4815 (class 2604 OID 17662)
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- TOC entry 4811 (class 2604 OID 17628)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 4813 (class 2604 OID 17640)
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- TOC entry 4805 (class 2604 OID 17614)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4902 (class 2606 OID 17902)
-- Name: api_logs api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4896 (class 2606 OID 17879)
-- Name: aws_settings aws_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aws_settings
    ADD CONSTRAINT aws_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4890 (class 2606 OID 17809)
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- TOC entry 4886 (class 2606 OID 17792)
-- Name: chat_threads chat_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_pkey PRIMARY KEY (id);


--
-- TOC entry 4875 (class 2606 OID 17735)
-- Name: favorite_prompts favorite_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_prompts
    ADD CONSTRAINT favorite_prompts_pkey PRIMARY KEY (id);


--
-- TOC entry 4877 (class 2606 OID 17737)
-- Name: favorite_prompts favorite_prompts_user_id_prompt_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_prompts
    ADD CONSTRAINT favorite_prompts_user_id_prompt_id_key UNIQUE (user_id, prompt_id);


--
-- TOC entry 4899 (class 2606 OID 17891)
-- Name: gcp_settings gcp_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gcp_settings
    ADD CONSTRAINT gcp_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4894 (class 2606 OID 17839)
-- Name: navigation_items navigation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.navigation_items
    ADD CONSTRAINT navigation_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4873 (class 2606 OID 17719)
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- TOC entry 4866 (class 2606 OID 17700)
-- Name: provider_access provider_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_access
    ADD CONSTRAINT provider_access_pkey PRIMARY KEY (id);


--
-- TOC entry 4868 (class 2606 OID 17702)
-- Name: provider_access provider_access_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_access
    ADD CONSTRAINT provider_access_user_id_provider_key UNIQUE (user_id, provider);


--
-- TOC entry 4882 (class 2606 OID 17759)
-- Name: provider_configs provider_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_configs
    ADD CONSTRAINT provider_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 4884 (class 2606 OID 17761)
-- Name: provider_configs provider_configs_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_configs
    ADD CONSTRAINT provider_configs_user_id_provider_key UNIQUE (user_id, provider);


--
-- TOC entry 4860 (class 2606 OID 17665)
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4862 (class 2606 OID 17667)
-- Name: role_permissions role_permissions_role_id_permission_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_key UNIQUE (role_id, permission);


--
-- TOC entry 4849 (class 2606 OID 17635)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 4851 (class 2606 OID 17633)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4855 (class 2606 OID 17643)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4857 (class 2606 OID 17645)
-- Name: user_roles user_roles_user_id_role_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_key UNIQUE (user_id, role_id);


--
-- TOC entry 4845 (class 2606 OID 17622)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4847 (class 2606 OID 17620)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4891 (class 1259 OID 17815)
-- Name: idx_chat_messages_thread_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_messages_thread_id ON public.chat_messages USING btree (thread_id);


--
-- TOC entry 4887 (class 1259 OID 17799)
-- Name: idx_chat_threads_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_threads_provider ON public.chat_threads USING btree (cloud_provider);


--
-- TOC entry 4888 (class 1259 OID 17798)
-- Name: idx_chat_threads_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_threads_user_id ON public.chat_threads USING btree (user_id);


--
-- TOC entry 4878 (class 1259 OID 17749)
-- Name: idx_favorite_prompts_prompt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_prompts_prompt_id ON public.favorite_prompts USING btree (prompt_id);


--
-- TOC entry 4879 (class 1259 OID 17748)
-- Name: idx_favorite_prompts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_prompts_user_id ON public.favorite_prompts USING btree (user_id);


--
-- TOC entry 4869 (class 1259 OID 17725)
-- Name: idx_prompts_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompts_category ON public.prompts USING btree (category);


--
-- TOC entry 4870 (class 1259 OID 17726)
-- Name: idx_prompts_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompts_provider ON public.prompts USING btree (cloud_provider);


--
-- TOC entry 4871 (class 1259 OID 17727)
-- Name: idx_prompts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompts_user_id ON public.prompts USING btree (user_id);


--
-- TOC entry 4863 (class 1259 OID 17709)
-- Name: idx_provider_access_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_access_provider ON public.provider_access USING btree (provider);


--
-- TOC entry 4864 (class 1259 OID 17708)
-- Name: idx_provider_access_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_access_user_id ON public.provider_access USING btree (user_id);


--
-- TOC entry 4880 (class 1259 OID 17767)
-- Name: idx_provider_configs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_configs_user_id ON public.provider_configs USING btree (user_id);


--
-- TOC entry 4858 (class 1259 OID 17673)
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_permissions_role_id ON public.role_permissions USING btree (role_id);


--
-- TOC entry 4852 (class 1259 OID 17657)
-- Name: idx_user_roles_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_role_id ON public.user_roles USING btree (role_id);


--
-- TOC entry 4853 (class 1259 OID 17656)
-- Name: idx_user_roles_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- TOC entry 4843 (class 1259 OID 17623)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 4903 (class 1259 OID 17903)
-- Name: ix_api_logs_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_api_logs_id ON public.api_logs USING btree (id);


--
-- TOC entry 4897 (class 1259 OID 17880)
-- Name: ix_aws_settings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_aws_settings_id ON public.aws_settings USING btree (id);


--
-- TOC entry 4900 (class 1259 OID 17892)
-- Name: ix_gcp_settings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gcp_settings_id ON public.gcp_settings USING btree (id);


--
-- TOC entry 4892 (class 1259 OID 17840)
-- Name: ix_navigation_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_navigation_items_id ON public.navigation_items USING btree (id);


--
-- TOC entry 4913 (class 2606 OID 17810)
-- Name: chat_messages chat_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.chat_threads(id) ON DELETE CASCADE;


--
-- TOC entry 4912 (class 2606 OID 17793)
-- Name: chat_threads chat_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4909 (class 2606 OID 17743)
-- Name: favorite_prompts favorite_prompts_prompt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_prompts
    ADD CONSTRAINT favorite_prompts_prompt_id_fkey FOREIGN KEY (prompt_id) REFERENCES public.prompts(id) ON DELETE CASCADE;


--
-- TOC entry 4910 (class 2606 OID 17738)
-- Name: favorite_prompts favorite_prompts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_prompts
    ADD CONSTRAINT favorite_prompts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4908 (class 2606 OID 17720)
-- Name: prompts prompts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4907 (class 2606 OID 17703)
-- Name: provider_access provider_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_access
    ADD CONSTRAINT provider_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4911 (class 2606 OID 17762)
-- Name: provider_configs provider_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_configs
    ADD CONSTRAINT provider_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4906 (class 2606 OID 17668)
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4904 (class 2606 OID 17651)
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4905 (class 2606 OID 17646)
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-08-20 10:18:19

--
-- PostgreSQL database dump complete
--

