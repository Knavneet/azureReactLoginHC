import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { providerAccessService } from '../lib/provider-access-service';
import { authService } from '../lib/auth-service';

interface ProviderAccessContextType {
  hasProviderAccess: boolean;
  isCheckingAccess: boolean;
  checkProviderAccess: () => Promise<boolean>;
}

const defaultContext: ProviderAccessContextType = {
  hasProviderAccess: true, // Default to true to prevent unnecessary redirects
  isCheckingAccess: true,
  checkProviderAccess: async () => true
};

const ProviderAccessContext = createContext<ProviderAccessContextType>(defaultContext);

export const useProviderAccess = () => useContext(ProviderAccessContext);

interface ProviderAccessProviderProps {
  children: React.ReactNode;
}

export const ProviderAccessProvider: React.FC<ProviderAccessProviderProps> = ({ children }) => {
  const [hasProviderAccess, setHasProviderAccess] = useState<boolean>(false); // Default to false for safety
  const [isCheckingAccess, setIsCheckingAccess] = useState<boolean>(true);

  const checkProviderAccess = useCallback(async () => {
    setIsCheckingAccess(true);
    try {
      const hasAccess = await providerAccessService.hasAccess();
      setHasProviderAccess(hasAccess);
    } catch (error) {
      console.error('Error checking provider access:', error);
      setHasProviderAccess(false); // Default to no access on error
    } finally {
      setIsCheckingAccess(false);
    }
  }, []);

  useEffect(() => {
    const handleAuthChange = () => {
      providerAccessService.resetAccessCheck();
      checkProviderAccess();
    };

    window.addEventListener('auth-state-changed', handleAuthChange);
    // The initial check is now handled by the auth service firing the event on load

    return () => {
      window.removeEventListener('auth-state-changed', handleAuthChange);
    };
  }, [checkProviderAccess]);

  return (
    <ProviderAccessContext.Provider value={{ hasProviderAccess, isCheckingAccess, checkProviderAccess }}>
      {children}
    </ProviderAccessContext.Provider>
  );
};
