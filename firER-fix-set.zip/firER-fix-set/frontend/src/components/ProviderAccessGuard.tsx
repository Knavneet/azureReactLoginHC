import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useProviderAccess } from '../contexts/ProviderAccessContext';

interface ProviderAccessGuardProps {
  children: React.ReactNode;
}

export function ProviderAccessGuard({ children }: ProviderAccessGuardProps) {
  const { hasProviderAccess, isCheckingAccess, checkProviderAccess } = useProviderAccess();
  const location = useLocation();

  // These paths are always accessible regardless of provider access
  const allowedPaths = ['/welcome', '/profile', '/login', '/register', '/forgot-password', '/reset-password'];
  const isAllowedPath = allowedPaths.includes(location.pathname);

  // Check provider access on mount
  useEffect(() => {
    checkProviderAccess();
  }, [checkProviderAccess]);

  // Don't render anything while checking, unless it's an allowed path
  if (isCheckingAccess && !isAllowedPath) {
    return null; // Or a loading spinner
  }

  // If no provider access and not on an allowed path, redirect to welcome page
  if (!hasProviderAccess && !isAllowedPath) {
    return <Navigate to="/welcome" state={{ from: location }} replace />;
  }

  // If has provider access or on an allowed path, render children
  return <>{children}</>;
}