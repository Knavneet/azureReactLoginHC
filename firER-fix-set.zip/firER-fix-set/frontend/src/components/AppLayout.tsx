import React, { useEffect, useState, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { PlusCircle, Cloud, ChevronDown } from 'lucide-react';
import { UserProfileDropdown } from './UserProfileDropdown';
import { CloudProvider } from '../types';
import toast from 'react-hot-toast';
import { useNavigation } from '../contexts/NavigationContext';
import { useProvider } from '../contexts/ProviderContext';
import { NavItem } from '../types/navigation';
import { API_BASE_URL } from '../config';
import { fetchWithAuth } from '../lib/api-utils';
import { authService } from '../lib/auth-service';

interface AppLayoutProps {
  children: React.ReactNode;
}

// Helper function to safely render icons
const renderIcon = (icon: any, props: any = {}) => {
  if (!icon) {
    console.log('No icon provided, using fallback');
    return <Cloud {...props} />; // Fallback icon
  }
  
  try {
    // Handle different types of icon components
    if (typeof icon === 'function') {
      // Direct function component
      const IconComponent = icon;
      return <IconComponent {...props} />;
    } else if (icon.type && typeof icon.type === 'function') {
      // React element with function type
      return React.cloneElement(icon, props);
    } else if (typeof icon === 'object' && icon.$$typeof) {
      // React forward ref component (like Lucide icons)
      const IconComponent = icon;
      return <IconComponent {...props} />;
    } else {
      console.error('Unrecognized icon format:', icon);
      return <Cloud {...props} />; // Fallback icon
    }
  } catch (error) {
    console.error('Error rendering icon:', error);
    return <Cloud {...props} />; // Fallback icon
  }
};

export function AppLayout({ children }: AppLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  // Add a ref to track if we've already shown a toast about provider access
  const providerAccessToastShownRef = useRef(false);
  
  // Get navigation items from context
  const { userNavItems, isLoading } = useNavigation();
  
  // Get provider state from context
  const { 
    activeProvider, 
    availableProviders, 
    hasAnyProviderAccess, 
    changeProvider, 
    providerNames,
    isLoading: isProviderLoading 
  } = useProvider();

  // Add ref for dropdown to detect outside clicks
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    // Add event listener
    document.addEventListener('mousedown', handleClickOutside);
    
    // Cleanup event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Check provider access for restricted pages
  useEffect(() => {
    if (isAuthenticated && !isLoading && !isProviderLoading) {
      const isRestrictedPage = location.pathname === '/chat' || location.pathname === '/prompt-library';
      
      if (isRestrictedPage && !hasAnyProviderAccess) {
        console.log('[AppLayout] User has no provider access, redirecting to profile page');
                // Only show toast if we haven't shown one already and we're not on the profile page
                if (location.pathname !== '/profile' && !providerAccessToastShownRef.current) {
                  toast.error('You need provider access to use this feature. Please contact your administrator.');
                  providerAccessToastShownRef.current = true;
                }
                navigate('/profile');
              }
            }
  }, [location.pathname, isAuthenticated, isLoading, isProviderLoading, hasAnyProviderAccess, navigate]);

  useEffect(() => {
    const updateAuthState = () => {
      setIsAuthenticated(authService.isAuthenticated());
    };

    // Initial check
    updateAuthState();

    // Listen for changes
    window.addEventListener('auth-state-changed', updateAuthState);

    return () => {
      window.removeEventListener('auth-state-changed', updateAuthState);
    };
  }, []);

  // Reset the toast shown flag when the component mounts or when the user changes
  useEffect(() => {
    providerAccessToastShownRef.current = false;
  }, [location.pathname]);



  const handleNewChat = () => {
    try {
      // Clear any selected chat thread if there is one
      localStorage.removeItem('selected_thread');
      
      // Clear any current messages in localStorage
      const currentSessionId = localStorage.getItem('current_session_id');
      if (currentSessionId) {
        localStorage.removeItem(`messages_${currentSessionId}`);
        localStorage.removeItem('current_session_id');
      }
      
      // Dispatch an event for the App component to listen for
      const event = new CustomEvent('newChatRequested');
      document.dispatchEvent(event);
      
      // Log the action
      console.log('Starting new chat... cleared previous session:', currentSessionId);
      
      // Navigate to the chat page if not already there
      if (location.pathname !== '/chat') {
        navigate('/chat');
      }
      // Don't force a page refresh - let the event handler take care of the state reset
      
      // Close the provider dropdown if it's open
      setIsDropdownOpen(false);
    } catch (error) {
      console.error('Error starting new chat:', error);
    }
  };

  // Handle provider change using the context
  const handleProviderChange = async (providerId: CloudProvider) => {
    try {
      await changeProvider(providerId);
      setIsDropdownOpen(false);
    } catch (error) {
      console.error('Error changing provider:', error);
    }
  };

  // Handle user logout
  // Logout is handled by the UserProfileDropdown component

  if (!isAuthenticated || isLoading || isProviderLoading) {
    return null; // Don't render anything while checking authentication, loading navigation, or loading providers
  }

  // If user is on a restricted page but has no provider access, show a message instead of the page content
  const isRestrictedPage = location.pathname === '/chat' || location.pathname === '/prompt-library';
  if (isRestrictedPage && !hasAnyProviderAccess) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-50">
        {/* <div className="bg-white p-8 rounded-lg shadow-md max-w-md text-center">
          <Cloud className="w-16 h-16 text-blue-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Provider Access Required</h1>
          <p className="text-gray-600 mb-6">
            You need access to at least one provider to use this feature. Please contact your administrator.
          </p>
          <button
            onClick={() => navigate('/profile')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Go to Profile
          </button>
        </div> */}
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-white">
      {/* Left Sidebar */}
      <div className="w-16 bg-[#f5f5f5] flex flex-col items-center py-4 border-r border-gray-200 flex-shrink-0">
        {/* Logo removed as requested */}
        <nav className="flex-1 flex flex-col items-center gap-4">
          {/* Dynamic sidebar navigation items */}
          {userNavItems
            .filter((item: NavItem) => item.position === 'sidebar' && item.isEnabled)
            .sort((a: NavItem, b: NavItem) => a.order - b.order)
            .map((item: NavItem) => {
              // Special case for new chat button which needs onClick handler
              if (item.id === 'new-chat' && (location.pathname === '/chat' || location.pathname === '/prompt-library')) {
                return (
                  <div key={item.id} className="group relative">
                    <button
                      onClick={handleNewChat}
                      className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                        location.pathname === item.path && !location.search
                          ? 'bg-blue-600 text-white' 
                          : 'bg-white text-gray-700 shadow-sm hover:bg-gray-100'
                      }`}
                      aria-label={item.title}
                    >
                      {renderIcon(item.icon, { className: "w-5 h-5" })}
                    </button>
                    <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none z-50">
                      {item.tooltip}
                    </div>
                  </div>
                );
              }
              
              // Handle external links
              if (item.isExternal) {
                return (
                  <div key={item.id} className="group relative">
                    <a
                      href={item.path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-lg flex items-center justify-center transition-colors bg-white text-gray-700 shadow-sm hover:bg-gray-100"
                      aria-label={`${item.title} (opens in new tab)`}
                    >
                      {renderIcon(item.icon, { className: "w-5 h-5" })}
                      <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full"></div>
                    </a>
                    <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none z-50">
                      {item.tooltip} (opens in new tab)
                    </div>
                  </div>
                );
              }
              
              // Regular internal navigation links
              return (
                <div key={item.id} className="group relative">
                  <Link
                    to={item.path}
                    className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                      (item.path === '/' ? location.pathname === item.path : location.pathname.startsWith(item.path))
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-gray-700 shadow-sm hover:bg-gray-100'
                    }`}
                    aria-label={item.title}
                  >
                    {renderIcon(item.icon, { className: "w-5 h-5" })}
                  </Link>
                  <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none z-50">
                    {item.tooltip}
                  </div>
                </div>
              );
            })}
        </nav>
        
        {/* Bottom navigation items */}
        <nav className="flex flex-col items-center gap-4">
          {userNavItems
            .filter((item: NavItem) => item.position === 'bottom' && item.isEnabled)
            .sort((a: NavItem, b: NavItem) => a.order - b.order)
            .map((item: NavItem) => (
              <div key={item.id} className="group relative">
                <Link
                  to={item.path}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                    location.pathname === item.path
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 shadow-sm hover:bg-gray-100'
                  }`}
                  aria-label={item.title}
                >
                  {renderIcon(item.icon, { className: `w-5 h-5 ${location.pathname === item.path ? 'text-white' : 'text-gray-500'}` })}
                </Link>
                <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none z-50">
                  {item.tooltip}
                </div>
              </div>
            ))}
        </nav>
    </div>

    {/* Main Content */}
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Top navigation bar with app name and user profile */}
      <div className="flex justify-between items-center px-6 py-3 bg-white border-b border-gray-100 sticky top-0 z-10">
        {/* App logo and name */}
        <div className="flex items-center gap-2">
          <Cloud className="h-6 w-6 text-blue-600" />
          <span className="text-xl font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">
            AI Force IntelliOps
          </span>
        </div>

          {/* Right side with cloud provider, new chat and user profile */}
          <div className="flex items-center gap-3">
            {/* Cloud Provider Dropdown - Only show on chat and prompt library pages */}
            {(location.pathname === '/chat' || location.pathname === '/prompt-library') && hasAnyProviderAccess && (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsDropdownOpen(!isDropdownOpen);
                  }}
                  className="px-3 py-1.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2 text-sm cursor-pointer"
                >
                  <Cloud className="w-4 h-4 text-blue-600" />
                  <span className="hidden md:inline">{providerNames[activeProvider]}</span>
                  <span className="md:hidden">{activeProvider.toUpperCase()}</span>
                  <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isDropdownOpen && (
                  <div 
                    className="absolute right-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {Object.entries(providerNames)
                      .filter(([id]) => availableProviders[id as CloudProvider])
                      .map(([id, name]) => (
                      <button
                        key={id}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleProviderChange(id as CloudProvider);
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2 cursor-pointer ${
                          activeProvider === id ? 'text-blue-600 bg-blue-50' : 'text-gray-700'
                        }`}
                      >
                        <Cloud className={`w-4 h-4 ${activeProvider === id ? 'text-blue-600' : 'text-gray-400'}`} />
                        {name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* New Chat Button */}
            {(location.pathname === '/chat' || location.pathname === '/prompt-library') && hasAnyProviderAccess && (
              <button 
                onClick={handleNewChat}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span className="hidden md:inline">New Chat</span>
              </button>
            )}
            
            {/* User Profile Dropdown */}
            <UserProfileDropdown />
          </div>
        </div>
        
        {/* Main scrollable content - make sure it fills available space */}
        <div className="flex-1 overflow-auto relative">
          {children}
        </div>
      </div>
    </div>
  );
}
