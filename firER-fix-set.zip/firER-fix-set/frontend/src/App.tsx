import React, { useState, useEffect, useCallback } from 'react';
import { ChatThread } from './components/ChatThread';
import { ChatInput } from './components/ChatInput';
import { PromptCard } from './components/PromptCard';
import { AppLayout } from './components/AppLayout';
import { SessionExpiredModal } from './components/SessionExpiredModal';
import { Message, Prompt, ChatHistory, ChatThread as ChatThreadType, CloudProvider } from './types';
import { 
  PlusCircle,
  Cloud,
  ChevronDown
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import toast, { Toaster } from 'react-hot-toast';
import * as promptService from './services/promptService';
import { authService } from './lib/auth-service';
import { configService } from './lib/config-service';
import { NavigationProvider } from './contexts/NavigationContext';
import { ProviderProvider, useProvider } from './contexts/ProviderContext';
import { SecurityCleanup } from './lib/security-cleanup';
import { chatService } from './lib/chat-service';

interface AppProps {
  initialThread?: ChatThreadType;
}

function ChatApp({ initialThread }: AppProps) {
  console.log('App - Received initialThread prop:', initialThread);

  const [messages, setMessages] = useState<Message[]>(initialThread?.messages || []);
  const [threads, setThreads] = useState<ChatThreadType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentMessage, setCurrentMessage] = useState('');
  const [sessionId, setSessionId] = useState<string>(initialThread?.session_id || '');
  const initialSessionId = initialThread?.session_id || ''; // Capture initial value
  console.log('App - Initializing sessionId state with:', initialSessionId);
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showSessionExpiredModal, setShowSessionExpiredModal] = useState(false);

  // Get provider state from context
  const { activeProvider, availableProviders, hasAnyProviderAccess, isLoading: isProviderLoading } = useProvider();

  // Effect 1: Manage sessionId based on initialThread
  useEffect(() => {
    console.log('App initialThread Effect - Starting with initialThread:', initialThread);
    
    if (initialThread && initialThread.session_id) {
      // If initialThread is provided, update the state with its data
      console.log('App initialThread Effect - Setting sessionId from initialThread:', initialThread.session_id);
      setSessionId(initialThread.session_id);
      
      // Always set messages if initialThread has them, regardless of whether they're empty
      if (initialThread.messages) {
        console.log('App initialThread Effect - Setting messages from initialThread:', initialThread.messages.length, 'messages');
        setMessages(initialThread.messages);
      } else {
        // Only clear messages if no messages in initialThread
        console.log('App initialThread Effect - No messages in initialThread, clearing messages');
        setMessages([]);
      }
      
      // Provider is now managed by the Provider Context, no need to set it here
    } else if (!sessionId) {
      // Only generate a new ID if no initialThread was given AND sessionId is currently empty.
      // This handles the very first load or clicking "New Chat".
      const newSessionId = uuidv4();
      console.log('App initialThread Effect - No initialThread or ID mismatch, generating initial sessionId:', newSessionId);
      setSessionId(newSessionId);
      // Clear messages for new chat
      setMessages([]);
    }
  }, [initialThread]); // Only depend on initialThread to avoid loops
  
  // Effect 2: Load prompts when provider changes or component mounts
  useEffect(() => {
    // Default to AWS provider if none is set
    const currentProvider = activeProvider || 'aws';
    let isMounted = true; // Flag to prevent state updates after unmount
    
    // Clear prompts immediately when provider changes to avoid stale data
    setPrompts([]);
    
    const loadPrompts = async () => {
      console.log(`App Prompt Loading Effect - Loading prompts for provider: ${currentProvider}`);
      
      try {
        // Get current user
        const currentUser = authService.getUser();
        const isAdmin = currentUser?.is_admin || false;
        
        // Use the same promptService as the Prompt Library
        let apiPrompts: Prompt[] = [];
        if (isAdmin) {
          // If admin, get all prompts
          apiPrompts = await promptService.getAllPromptsAdmin(
            undefined, // No category filter
            currentProvider // Provider filter
          );
        } else {
          // If regular user, get user prompts + system prompts
          apiPrompts = await promptService.getPrompts(
            undefined, // No category filter
            currentProvider // Provider filter
          );
        }
        
        // If component unmounted or provider changed during API call, don't update state
        if (!isMounted) return;
        
        console.log(`App Prompt Loading Effect - Loaded ${apiPrompts.length} prompts from API`);
        
        // Load favorites from API
        try {
          const favorites = await promptService.getFavoritePrompts();
          const favoriteIds = new Set(favorites.map(p => p.id));
          
          const promptsWithFavorites = apiPrompts.map((prompt: Prompt) => ({
            ...prompt,
            is_favorite: favoriteIds.has(prompt.id)
          }));
          
          // Final check before updating state
          if (!isMounted) return;
          
          setPrompts(promptsWithFavorites);
          console.log(`App Prompt Loading Effect - Successfully loaded ${promptsWithFavorites.length} prompts for ${currentProvider}`);
          
          // Save the current provider to localStorage for persistence
          localStorage.setItem('selectedProvider', currentProvider);
        } catch (error) {
          if (!isMounted) return;
          console.error('Error loading favorites:', error);
          setPrompts(apiPrompts);
        }
      } catch (error) {
        if (!isMounted) return;
        console.error('Error loading prompts:', error);
        setPrompts([]);
      }
    };
    
    // Start loading prompts
    loadPrompts();
    
    // Provider is managed by the Provider Context
    
    // Cleanup function to prevent state updates after unmount
    return () => {
      isMounted = false;
    };
  }, [activeProvider]); // Only depend on activeProvider

  // Function to clean up threads older than 30 days
  const cleanupOldThreads = (threads: ChatThreadType[]): ChatThreadType[] => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    return threads.filter(thread => {
      const threadDate = new Date(thread.timestamp);
      return threadDate > thirtyDaysAgo;
    });
  };

  // Effect 2: Load threads from database once sessionId is stable
  useEffect(() => {
    console.log('App Thread Load Effect - Running with sessionId:', sessionId);

    // Don't load threads if sessionId isn't set yet
    if (!sessionId) {
      console.log('App Thread Load Effect - Skipping thread load, no sessionId');
      return;
    }

    // Load threads from database instead of localStorage
    const loadThreadsFromDatabase = async () => {
      try {
        const dbThreads = await chatService.getChatThreads();
        const mappedThreads = dbThreads.map((thread: any) => ({
          id: thread.id.toString(),
          session_id: thread.title?.includes('(') ? 
            thread.title.split('(').pop()?.replace(')', '') || sessionId : 
            sessionId, // Extract session_id from title or use current
          title: thread.title?.replace(/\s*\([^)]*\)$/, '') || 'Untitled Chat', // Remove session_id from title
          lastMessage: '', // Will be populated from messages if needed
          timestamp: thread.updated_at || thread.created_at || new Date().toISOString(),
          messages: [] // Messages will be loaded separately when needed
        }));
        
        setThreads(mappedThreads);
        console.log('Loaded threads from database:', mappedThreads.length);
      } catch (error) {
        console.error('Failed to load threads from database:', error);
        // Fallback to localStorage if database fails
        try {
          const savedThreads = localStorage.getItem('chat_threads');
          if (savedThreads) {
            const parsedThreads = JSON.parse(savedThreads);
            const cleanedThreads = cleanupOldThreads(parsedThreads);
            setThreads(cleanedThreads);
            console.log('Fallback: Loaded threads from localStorage:', cleanedThreads.length);
          }
        } catch (localError) {
          console.error('Error parsing saved threads from localStorage:', localError);
        }
      }
    };

    loadThreadsFromDatabase();
  }, [sessionId]); // Dependencies: Run when sessionId changes

  // Provider changes are now handled by the Provider Context

  // Add new effect to listen for "new chat" events from AppLayout
  useEffect(() => {
    const handleNewChatEvent = () => {
      console.log('App: New chat event received');
      
      // Clear current messages
      setMessages([]);
      setCurrentMessage('');
      
      // Generate new session ID
      const newSessionId = uuidv4();
      console.log('Created new session ID:', newSessionId);
      
      // Update state and localStorage
      setSessionId(newSessionId);
      localStorage.setItem('current_session_id', newSessionId);
    };
    
    document.addEventListener('newChatRequested', handleNewChatEvent);
    
    return () => {
      document.removeEventListener('newChatRequested', handleNewChatEvent);
    };
  }, []);

  const formatMessagesForHistory = (messages: Message[]): ChatHistory[] => {
    return messages.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'assistant',
      content: msg.content
    }));
  };

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      timestamp: new Date().toISOString(),
      sender: 'user',
    };
    
    const loadingMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: '',
      timestamp: new Date().toISOString(),
      sender: 'system',
      status: 'loading',
    };
    
    setMessages(prev => [...prev, userMessage, loadingMessage]);
    setIsLoading(true);

    try {
      const chatHistory = formatMessagesForHistory(messages);
      console.log('Sending message with provider:', activeProvider);
      
      // Send the chat message - this will now automatically save to database
      const response = await chatService.sendChatMessage({
        session_id: sessionId,
        user_message: content,
        history: chatHistory,
        provider: activeProvider // Include the provider in the request
      });

      const responseMessage: Message = {
        id: loadingMessage.id,
        content: response.response,
        timestamp: new Date().toISOString(),
        sender: 'system',
        status: 'success',
      };

      // Update local messages state
      setMessages(prev => prev.map(msg => 
        msg.id === loadingMessage.id ? responseMessage : msg
      ));

      // Refresh threads from database to get the latest data
      try {
        const updatedThreads = await chatService.getChatThreads();
        setThreads(updatedThreads.map((thread: any) => ({
          id: thread.id.toString(),
          session_id: sessionId, // Map session_id appropriately
          title: thread.title || 'Untitled Chat',
          lastMessage: '', // Will be populated from messages if needed
          timestamp: thread.updated_at || thread.created_at || new Date().toISOString(),
          messages: [] // Messages will be loaded separately when needed
        })));
      } catch (error) {
        console.error('Failed to refresh threads from database:', error);
        // Continue with local state if database refresh fails
      }

    } catch (error) {
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'An unexpected error occurred. Please try again.';
      
      const errorResponse: Message = {
        id: loadingMessage.id,
        content: errorMessage,
        timestamp: new Date().toISOString(),
        sender: 'system',
        status: 'error',
      };
      
      setMessages(prev => prev.map(msg => 
        msg.id === loadingMessage.id ? errorResponse : msg
      ));
    } finally {
      setIsLoading(false);
    }
  };

  const handlePromptSelect = (command: string) => {
    setCurrentMessage(command);
  };

  const handleNewChat = async () => {
    const newSessionId = uuidv4();
    setSessionId(newSessionId);
    setMessages([]);
    setCurrentMessage('');
    
    // Update localStorage for session tracking
    localStorage.setItem('current_session_id', newSessionId);
    
    // Note: We don't create a thread in the database until the first message is sent
    // This avoids creating empty threads
  };

  const handleCategorySelect = (category: string | null) => {
    setSelectedCategory(category);
    setIsSidebarExpanded(false);
  };

  const handleToggleFavorite = (promptId: string) => {
    const updatedPrompts = prompts.map(prompt => 
      prompt.id === promptId
        ? { ...prompt, is_favorite: !prompt.is_favorite }
        : prompt
    );
    
    const sortedPrompts = [...updatedPrompts].sort((a, b) => {
      if (a.is_favorite && !b.is_favorite) return -1;
      if (!a.is_favorite && b.is_favorite) return 1;
      return 0;
    });
    
    localStorage.setItem('favorite_prompts', JSON.stringify(
      sortedPrompts.filter(p => p.is_favorite).map(p => p.id)
    ));
    
    setPrompts(sortedPrompts);
  };

  // Edit and delete functionality has been removed from the PromptCard component

  const categories = [...new Set(prompts.map(prompt => prompt.category))];
  const filteredPrompts = selectedCategory
    ? prompts.filter(prompt => prompt.category === selectedCategory)
    : prompts;

  const providerNames: Record<CloudProvider, string> = {
    aws: 'Amazon Web Services',
    azure: 'Microsoft Azure',
    gcp: 'Google Cloud Platform',
    onprem: 'On-Premises Infrastructure'
  };

  return (
    <AppLayout>
      <div className="flex flex-col h-full w-full">
        {messages.length === 0 ? (
          // Show prompt cards when no messages
          <div className="flex-1 overflow-auto h-full">
            <div className="h-full p-4 md:p-6">
              <div className="max-w-6xl mx-auto">
                <h2 className="text-lg font-medium mb-4">Select a prompt to get started</h2>
                
                <div className="flex overflow-x-auto space-x-2 pb-4">
                  <button
                    onClick={() => handleCategorySelect(null)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap flex-shrink-0 ${
                      selectedCategory === null
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    All
                  </button>
                  {categories.map(category => (
                    <button
                      key={category}
                      onClick={() => handleCategorySelect(category)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap flex-shrink-0 ${
                        selectedCategory === category
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-6">
                  {filteredPrompts.map((promptItem) => (
                    <PromptCard
                      key={promptItem.id}
                      prompt={promptItem}
                      onSelect={() => handlePromptSelect(promptItem.command)}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          // Show chat thread when there are messages
          <div className="flex-1 overflow-auto h-full">
            <ChatThread messages={messages} />
          </div>
        )}

        {/* Chat input always at the bottom */}
        <div className="bg-[#f9f9f9] border-t border-gray-200 w-full sticky bottom-0 z-10">
          <div className="max-w-3xl mx-auto w-full">
            <ChatInput
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
              message={currentMessage}
              setMessage={setCurrentMessage}
              prompts={filteredPrompts}
            />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

export function App({ initialThread }: AppProps) {
  const [showSessionExpiredModal, setShowSessionExpiredModal] = useState(false);
  
  // Security cleanup and validation on app initialization
  useEffect(() => {
    // Perform security cleanup and validation
    SecurityCleanup.cleanupStoredPasswords();
    
    // Validate security compliance in development
    if (process.env.NODE_ENV === 'development') {
      const isCompliant = SecurityCleanup.validateSecurityCompliance();
      if (!isCompliant) {
        console.warn('[Security] Security compliance check failed. Check console for details.');
      }
    }
  }, []);
  
  // Listen for JWT expiration events
  useEffect(() => {
    const handleJwtExpired = () => {
      console.log('JWT expiration event received');
      setShowSessionExpiredModal(true);
    };
    
    // Add event listener for JWT expiration
    window.addEventListener('jwt-expired', handleJwtExpired);
    
    return () => {
      window.removeEventListener('jwt-expired', handleJwtExpired);
    };
  }, []);
  
  return (
    <>
      <NavigationProvider>
        <ProviderProvider>
          <ChatApp initialThread={initialThread} />
        </ProviderProvider>
      </NavigationProvider>
      
      {/* Toast notifications */}
      <Toaster position="top-right" />
      
      {/* Session expired modal */}
      <SessionExpiredModal 
        show={showSessionExpiredModal} 
        onClose={() => setShowSessionExpiredModal(false)} 
      />
    </>
  );
}