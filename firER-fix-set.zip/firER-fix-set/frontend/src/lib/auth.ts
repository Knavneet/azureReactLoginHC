interface User {
  id: string;
  email: string;
  created_at: string;
}

interface AuthResponse {
  user: User | null;
  error: string | null;
}

// This service is deprecated - all authentication should go through auth-service.ts
// which uses the backend API with httpOnly cookies
class AuthService {
  private readonly STORAGE_KEY = 'auth_user';

  constructor() {
    console.warn('This auth service is deprecated. Use auth-service.ts instead.');
  }

  private getStoredUser(): User | null {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored ? JSON.parse(stored) : null;
  }

  private setStoredUser(user: User | null): void {
    if (user) {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(this.STORAGE_KEY);
    }
  }

  async signUp(email: string, password: string): Promise<AuthResponse> {
    return { user: null, error: 'This service is deprecated. Use backend authentication.' };
  }

  async signIn(email: string, password: string): Promise<AuthResponse> {
    return { user: null, error: 'This service is deprecated. Use backend authentication.' };
  }

  async signOut(): Promise<void> {
    this.setStoredUser(null);
  }

  async getSession(): Promise<{ user: User | null }> {
    const user = this.getStoredUser();
    return { user };
  }

  async resetPassword(email: string): Promise<{ error: string | null }> {
    return { error: 'This service is deprecated. Use backend authentication.' };
  }

  async updatePassword(password: string): Promise<{ error: string | null }> {
    return { error: 'This service is deprecated. Use backend authentication.' };
  }

  onAuthStateChange(callback: (user: User | null) => void): { unsubscribe: () => void } {
    const handler = () => {
      callback(this.getStoredUser());
    };

    window.addEventListener('storage', handler);
    return {
      unsubscribe: () => window.removeEventListener('storage', handler),
    };
  }
}

export const auth = new AuthService();