/**
 * API Utilities
 * Provides wrapper functions for API calls with JWT expiration handling
 * Updated to work with httpOnly cookies for secure token storage
 */

import { toast } from 'react-hot-toast';
import { AUTH_USER } from '../constants/storageKeys';

// Flag to prevent multiple redirects
let isHandlingExpiration = false;

/**
 * Handles JWT expiration by clearing auth data and redirecting to login
 */
function handleJWTExpiration(errorMessage?: string) {
  if (isHandlingExpiration) {
    return;
  }

  console.log('[API Utils] Handling JWT expiration:', errorMessage);
  isHandlingExpiration = true;

  try {
    // Clear auth data (tokens are handled by httpOnly cookies)
    localStorage.removeItem(AUTH_USER);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedProvider');
    
    // Show toast notification
    toast.error(
      'Your session has expired. Please login again.', 
      { 
        id: 'session-expired',
        duration: 5000,
        position: 'top-center'
      }
    );
    
    // Store the current path for redirecting back after login
    const currentPath = window.location.pathname + window.location.search;
    if (!['/login', '/register'].includes(window.location.pathname)) {
      sessionStorage.setItem('redirectAfterLogin', currentPath);
    }
    
    // Redirect to login page
    window.location.href = '/login';
    
  } catch (error) {
    console.error('[API Utils] Error handling JWT expiration:', error);
  } finally {
    // Reset the flag after a delay
    setTimeout(() => {
      isHandlingExpiration = false;
    }, 5000);
  }
}

/**
 * Check if the response indicates JWT expiration
 */
function isJWTExpired(response: Response, responseText: string): boolean {
  // Check status code
  if (response.status === 401) {
    return true;
  }
  
  // Check response text for JWT-related errors
  const lowerText = responseText.toLowerCase();
  return (
    lowerText.includes('jwt') ||
    lowerText.includes('token') ||
    lowerText.includes('expired') ||
    lowerText.includes('unauthorized') ||
    lowerText.includes('signature')
  );
}

/**
 * Enhanced fetch wrapper that handles JWT expiration with httpOnly cookies
 */
export async function fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
  // Set up headers (no need to add Authorization header with httpOnly cookies)
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...options.headers as Record<string, string>,
  };
  
  const requestOptions: RequestInit = {
    ...options,
    headers,
    credentials: 'include', // Important: include cookies in requests
  };
  
  try {
    const response = await fetch(url, requestOptions);
    
    // Check for JWT expiration
    if (!response.ok) {
      let responseText = '';
      try {
        responseText = await response.clone().text();
      } catch (e) {
        // Ignore errors when reading response text
      }
      
      if (isJWTExpired(response, responseText)) {
        handleJWTExpiration(`API call failed with status ${response.status}: ${responseText}`);
        throw new Error('JWT expired');
      }
    }
    
    return response;
  } catch (error) {
    // Check if it's a network error that might be related to auth
    if (error instanceof Error) {
      const message = error.message.toLowerCase();
      if (message.includes('jwt') || message.includes('token') || message.includes('unauthorized')) {
        handleJWTExpiration(error.message);
      }
    }
    throw error;
  }
}

/**
 * Convenience method for GET requests with auth
 */
export async function getWithAuth(url: string): Promise<any> {
  const response = await fetchWithAuth(url, { method: 'GET' });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}

/**
 * Convenience method for POST requests with auth
 */
export async function postWithAuth(url: string, data?: any): Promise<any> {
  const response = await fetchWithAuth(url, {
    method: 'POST',
    body: data ? JSON.stringify(data) : undefined,
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}

/**
 * Convenience method for PUT requests with auth
 */
export async function putWithAuth(url: string, data?: any): Promise<any> {
  const response = await fetchWithAuth(url, {
    method: 'PUT',
    body: data ? JSON.stringify(data) : undefined,
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}

/**
 * Convenience method for DELETE requests with auth
 */
export async function deleteWithAuth(url: string): Promise<any> {
  const response = await fetchWithAuth(url, { method: 'DELETE' });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
} 