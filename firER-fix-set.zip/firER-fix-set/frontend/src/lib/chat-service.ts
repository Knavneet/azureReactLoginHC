/**
 * Chat Service
 * Handles chat threads and messages with PostgreSQL backend
 */

import { Message, ChatThread, ChatRequest, ChatResponse } from '../types';
import { authService } from './auth-service';
import { API_BASE_URL, CHAT_API_URL, API_CONFIG } from '../config';
import { AUTH_TOKEN, CHAT_THREADS } from '../constants/storageKeys';

// Timeout settings from config
const TIMEOUT_MS = API_CONFIG.timeout * 4; // 4x the standard timeout for chat operations

// Default request headers
const DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json'
};

// Error handling helper
async function handleResponse(response: Response) {
  if (!response.ok) {
    const errorText = await response.text();
    let errorMessage = 'API request failed';
    
    try {
      const errorData = JSON.parse(errorText);
      errorMessage = errorData.detail || errorData.message || errorMessage;
    } catch (e) {
      errorMessage = errorText || response.statusText || errorMessage;
    }
    
    throw new Error(errorMessage);
  }
  
  return response.json();
}

class ChatService {
  private chatThreads: ChatThread[] = [];
  private isLoaded = false;
  
  /**
   * Clear the cache and force a fresh load from database
   */
  public clearCache(): void {
    this.chatThreads = [];
    this.isLoaded = false;
    console.log('[ChatService] Cache cleared, next getChatThreads() will fetch from database');
  }
  
  /**
   * Get all chat threads for the current user
   */
  async getChatThreads(): Promise<ChatThread[]> {
    // Always check authentication first
    if (!authService.isAuthenticated()) {
      console.error('[ChatService] User not authenticated, cannot fetch chat threads');
      throw new Error('Not authenticated');
    }
    
    // Return cached data only if we have it and user is still authenticated
    if (this.isLoaded && this.chatThreads.length > 0) {
      console.log('[ChatService] Returning cached chat threads:', this.chatThreads.length);
      return this.chatThreads;
    }
    
    console.log('[ChatService] Fetching chat threads from database...');
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads`, {
        method: 'GET',
        headers: DEFAULT_HEADERS,
        credentials: 'include' // Important: include cookies in the request
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[ChatService] Failed to fetch chat threads:', response.status, errorText);
        
        // If it's an authentication error, don't fall back to localStorage
        if (response.status === 401 || response.status === 403) {
          throw new Error('Authentication failed');
        }
        
        throw new Error(`Failed to fetch chat threads: ${errorText}`);
      }
      
      const data = await handleResponse(response);
      console.log('[ChatService] Successfully fetched chat threads from database:', data.length, 'threads');
      
      this.chatThreads = data;
      this.isLoaded = true;
      return this.chatThreads;
    } catch (error) {
      console.error('[ChatService] Error fetching chat threads:', error);
      
      // Don't fall back to localStorage for authentication errors
      const errorMessage = error instanceof Error ? error.message : String(error);
      if (errorMessage.includes('Authentication') || errorMessage.includes('Not authenticated')) {
        throw error;
      }
      
      // For other errors, still throw to let the caller handle fallback
      throw error;
    }
  }
  
  /**
   * Get a specific chat thread with messages
   */
  async getChatThread(threadId: string): Promise<ChatThread> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads/${threadId}`, {
        method: 'GET',
        headers: DEFAULT_HEADERS,
        credentials: 'include'
      });
      
      return handleResponse(response);
    } catch (error) {
      console.error(`Failed to fetch chat thread ${threadId}:`, error);
      throw error;
    }
  }
  
  /**
   * Create a new chat thread
   */
  async createChatThread(title: string, provider: string): Promise<ChatThread> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads`, {
        method: 'POST',
        headers: DEFAULT_HEADERS,
        credentials: 'include',
        body: JSON.stringify({ title, provider })
      });
      
      const newThread = await handleResponse(response);
      
      // Update local cache
      this.chatThreads.push(newThread);
      
      return newThread;
    } catch (error) {
      console.error('Failed to create chat thread:', error);
      throw error;
    }
  }
  
  /**
   * Update a chat thread
   */
  async updateChatThread(threadId: string, title: string): Promise<ChatThread> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads/${threadId}`, {
        method: 'PUT',
        headers: DEFAULT_HEADERS,
        credentials: 'include',
        body: JSON.stringify({ title })
      });
      
      const updatedThread = await handleResponse(response);
      
      // Update local cache
      const index = this.chatThreads.findIndex(t => t.id === threadId);
      if (index >= 0) {
        this.chatThreads[index] = updatedThread;
      }
      
      return updatedThread;
    } catch (error) {
      console.error(`Failed to update chat thread ${threadId}:`, error);
      throw error;
    }
  }
  
  /**
   * Delete a chat thread
   */
  async deleteChatThread(threadId: string): Promise<boolean> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads/${threadId}`, {
        method: 'DELETE',
        headers: DEFAULT_HEADERS,
        credentials: 'include'
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }
      
      // Update local cache
      this.chatThreads = this.chatThreads.filter(t => t.id !== threadId);
      
      return true;
    } catch (error) {
      console.error(`Failed to delete chat thread ${threadId}:`, error);
      throw error;
    }
  }
  
  /**
   * Send a chat message
   */
  async sendChatMessage(request: ChatRequest): Promise<ChatResponse> {
    try {
      console.log('=== CHAT REQUEST DEBUG ===');
      console.log('Request object:', JSON.stringify(request, null, 2));
      
      // Create AbortController for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);
      
      // Determine the correct endpoint based on the provider (same logic as api.ts)
      const provider = request.provider || 'aws'; // Default to AWS if not specified
      let endpoint: string;
      let requestBody: any;
      
      if (provider === 'aws') {
        endpoint = `${API_BASE_URL}/api/aws-bedrock/chat`;
        requestBody = {
          message: request.user_message,
          session_id: request.session_id,
          history: request.history || [],
          provider: provider
        };
      } else if (provider === 'gcp') {
        endpoint = `${API_BASE_URL}/api/gcp-chat`;
        requestBody = {
          session_id: request.session_id,
          new_message: {
            role: 'user',
            parts: [{ text: request.user_message }]
          },
          start_session: !request.history || request.history.length === 0,
          provider: provider
        };
      } else {
        // For other providers or fallback, use the general chat endpoint
        endpoint = `${API_BASE_URL}/api/chat/`;
        requestBody = {
          session_id: request.session_id,
          user_message: request.user_message,
          history: request.history || [],
          provider: provider
        };
      }
      
      console.log(`Sending chat request to ${provider.toUpperCase()} backend:`, endpoint);
      console.log('Request body:', JSON.stringify(requestBody, null, 2));
      
      // Use cookie-based authentication
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: DEFAULT_HEADERS,
        credentials: 'include',
        body: JSON.stringify(requestBody),
        signal: controller.signal
      });
      
      console.log('Response status:', response.status);
      
      // Clear the timeout
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = 'Failed to send message. Please try again.';
        
        console.log('Error response:', errorText);
        
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorData.error || errorMessage;
        } catch (e) {
          // If error text is not JSON, use status text
          errorMessage = response.statusText || errorMessage;
        }

        throw new Error(errorMessage);
      }

      const data = await response.json();
      console.log('Response data:', JSON.stringify(data, null, 2));

      if (!data || typeof data.response !== 'string') {
        throw new Error('Invalid response format received from server');
      }

      return {
        session_id: data.session_id || request.session_id,
        response: data.response
      };
    } catch (error) {
      console.error('Failed to send chat message:', error);
      throw error;
    }
  }
  
  /**
   * Save a chat message to the database
   */
  async saveChatMessage(threadId: string, message: Omit<Message, 'id'>): Promise<Message> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads/${threadId}/messages`, {
        method: 'POST',
        headers: DEFAULT_HEADERS,
        credentials: 'include',
        body: JSON.stringify(message)
      });
      
      return handleResponse(response);
    } catch (error) {
      console.error(`Failed to save chat message to thread ${threadId}:`, error);
      throw error;
    }
  }
  
  /**
   * Get messages for a chat thread
   */
  async getChatMessages(threadId: string): Promise<Message[]> {
    if (!authService.isAuthenticated()) {
      throw new Error('Not authenticated');
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/threads/${threadId}/messages`, {
        method: 'GET',
        headers: DEFAULT_HEADERS,
        credentials: 'include'
      });
      
      return handleResponse(response);
    } catch (error) {
      console.error(`Failed to fetch messages for thread ${threadId}:`, error);
      throw error;
    }
  }
  
  /**
   * Migrate chat history from localStorage
   */
  async migrateChatHistoryFromLocalStorage(): Promise<boolean> {
    if (!authService.isAuthenticated()) {
      console.error('Cannot migrate chat history: Not authenticated');
      return false;
    }
    
    try {
      // Check if migration has already been performed
      if (localStorage.getItem('chat_history_migrated')) {
        return true;
      }
      
      // Get chat history from localStorage
      const chatHistoryJson = localStorage.getItem('chat_history');
      if (!chatHistoryJson) {
        // No chat history to migrate
        localStorage.setItem('chat_history_migrated', 'true');
        return true;
      }
      
      const chatHistory = JSON.parse(chatHistoryJson);
      if (!chatHistory || typeof chatHistory !== 'object') {
        // No valid chat history to migrate
        localStorage.setItem('chat_history_migrated', 'true');
        return true;
      }
      
      // Migrate each chat thread
      for (const [sessionId, messages] of Object.entries(chatHistory)) {
        if (Array.isArray(messages) && messages.length > 0) {
          try {
            // Create a new chat thread
            const firstMessage = messages[0];
            const title = firstMessage.content.substring(0, 50) + (firstMessage.content.length > 50 ? '...' : '');
            const provider = sessionId.split('-')[0] || 'unknown';
            
            const thread = await this.createChatThread(title, provider);
            
            // Add messages to the thread
            for (const message of messages) {
              await this.saveChatMessage(thread.id, {
                content: message.content,
                timestamp: message.timestamp || new Date().toISOString(),
                sender: message.sender,
                role: message.role || (message.sender === 'user' ? 'user' : 'assistant'),
                status: 'success'
              });
            }
            
            console.log(`Migrated chat thread: ${title}`);
          } catch (e) {
            console.error(`Failed to migrate chat thread for session ${sessionId}:`, e);
          }
        }
      }
      
      // Mark migration as completed
      localStorage.setItem('chat_history_migrated', 'true');
      return true;
    } catch (error) {
      console.error('Failed to migrate chat history:', error);
      return false;
    }
  }
}

// Export a singleton instance
export const chatService = new ChatService();
