/**
 * Axios Interceptor for handling API errors
 * Particularly focused on JWT expiration errors
 * Updated to work with httpOnly cookies for secure token storage
 */

import axios from 'axios';
import { toast } from 'react-hot-toast';
import { authService } from './auth-service';
import { AUTH_USER } from '../constants/storageKeys';

// Flag to prevent multiple redirects
let isHandlingExpiration = false;

import logger from './logger';

/**
 * Handles token expiration and authentication errors
 */
function handleTokenExpiration(errorMessage: string) {
  if (isHandlingExpiration) {
    logger.debug('Already handling token expiration, skipping');
    return;
  }

  logger.warn('Handling token expiration:', errorMessage);
  isHandlingExpiration = true;

  try {
    // Clear auth data (tokens are handled by httpOnly cookies)
    localStorage.removeItem(AUTH_USER);
    
    // Log the user out
    authService.logout();
    
    // Show toast notification
    toast.error(
      'Your session has expired. Please login again.', 
      { 
        id: 'session-expired',
        duration: 5000,
        position: 'top-center'
      }
    );
    
    // Dispatch JWT expiration event for any components that might be listening
    window.dispatchEvent(new Event('jwt-expired'));
    
    // Store the current path for redirecting back after login
    const currentPath = window.location.pathname + window.location.search;
    if (!['/login', '/register'].includes(window.location.pathname)) {
      sessionStorage.setItem('redirectAfterLogin', currentPath);
    }
    
    // Redirect to login page
    window.location.href = '/login';
    
  } catch (error) {
    logger.error('Error handling token expiration:', error);
  } finally {
    // Reset the flag after a delay to prevent issues with future logins
    setTimeout(() => {
      isHandlingExpiration = false;
    }, 5000);
  }
}

/**
 * Check if an error is an authentication error
 */
export function isAuthError(error: any): boolean {
  if (!error.response) {
    return false;
  }

  const status = error.response.status;
  const data = error.response.data;

  // Check for 401 Unauthorized
  if (status === 401) {
    return true;
  }

  // Check for JWT-related error messages
  if (data && typeof data === 'object') {
    const message = (data.detail || data.message || '').toString().toLowerCase();
    return (
      message.includes('jwt') ||
      message.includes('token') ||
      message.includes('signature') ||
      message.includes('expired') ||
      message.includes('unauthorized')
    );
  }

  return false;
}

/**
 * Get error message from axios error
 */
function getErrorMessage(error: any): string {
  if (error.response?.data?.detail) {
    return error.response.data.detail;
  }
  if (error.response?.data?.message) {
    return error.response.data.message;
  }
  if (error.message) {
    return error.message;
  }
  return 'An unknown error occurred';
}

/**
 * Sets up Axios interceptors for global error handling
 */
export function setupAxiosInterceptors() {
  // Request interceptor to ensure credentials are included
  axios.interceptors.request.use(
    (config) => {
      // Ensure credentials are included for cookie-based auth
      config.withCredentials = true;
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Response interceptor for handling errors
  axios.interceptors.response.use(
    (response) => {
      return response;
    },
    (error) => {
      const errorMessage = getErrorMessage(error);
      logger.error('API Error:', { 
        error: errorMessage,
        url: error.config?.url,
        method: error.config?.method,
        status: error.response?.status,
        response: error.response?.data
      });
      
      // Handle authentication errors
      if (isAuthError(error)) {
        handleTokenExpiration(errorMessage);
      }
      
      return Promise.reject(error);
    }
  );
  
  logger.info('Axios interceptors initialized for httpOnly cookie authentication');
}

// Initialize interceptors when this module is imported
setupAxiosInterceptors();
