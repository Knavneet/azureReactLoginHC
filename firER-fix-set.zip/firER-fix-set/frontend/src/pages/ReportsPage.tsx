import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Users, DollarSign, Download, Filter } from 'lucide-react';
import { AppLayout } from '../components/AppLayout';

export const ReportsPage: React.FC = () => {
  const [selectedReport, setSelectedReport] = useState('usage');
  const [dateRange, setDateRange] = useState('7d');

  // Mock data - replace with actual API calls
  const [reportData, setReportData] = useState({
    usage: { value: '1,234', change: '+12%', trend: 'up' },
    users: { value: '456', change: '+8%', trend: 'up' },
    costs: { value: '$12,345', change: '-5%', trend: 'down' },
    performance: { value: '98.5%', change: '+2%', trend: 'up' }
  });

  const reports = [
    { id: 'usage', name: 'Usage Reports', icon: BarChart3, description: 'System usage analytics' },
    { id: 'users', name: 'User Reports', icon: Users, description: 'User activity and engagement' },
    { id: 'costs', name: 'Cost Reports', icon: DollarSign, description: 'Financial and cost analysis' },
    { id: 'performance', name: 'Performance Reports', icon: TrendingUp, description: 'System performance metrics' }
  ];

  return (
    <AppLayout>
      <div className="flex-1 overflow-auto bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
                <p className="text-gray-600">Comprehensive insights and analytics dashboard</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <select 
                value={dateRange} 
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
              </select>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                <Download className="w-4 h-4" />
                Export
              </button>
            </div>
          </div>

          {/* Report Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {reports.map((report) => {
              const Icon = report.icon;
              const data = reportData[report.id as keyof typeof reportData];
              
              return (
                <div 
                  key={report.id}
                  onClick={() => setSelectedReport(report.id)}
                  className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedReport === report.id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <Icon className={`w-6 h-6 ${selectedReport === report.id ? 'text-blue-600' : 'text-gray-600'}`} />
                    <span className={`text-sm font-medium ${
                      data.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {data.change}
                    </span>
                  </div>
                  
                  <h3 className="font-semibold text-gray-900 mb-1">{report.name}</h3>
                  <p className="text-sm text-gray-600 mb-2">{report.description}</p>
                  <p className="text-2xl font-bold text-gray-900">{data.value}</p>
                </div>
              );
            })}
          </div>

          {/* Detailed Report View */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                {reports.find(r => r.id === selectedReport)?.name} - Detailed View
              </h2>
              
              <button className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 transition-colors">
                <Filter className="w-4 h-4" />
                Filters
              </button>
            </div>

            {/* Mock Chart/Data Area */}
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
              <div className="text-center">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 font-medium">Chart visualization for {selectedReport} reports</p>
                <p className="text-sm text-gray-500 mt-1">Connect your data source to see real-time analytics</p>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-1">Total Records</h4>
                <p className="text-2xl font-bold text-blue-600">2,847</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-1">Average Value</h4>
                <p className="text-2xl font-bold text-green-600">$456</p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-1">Growth Rate</h4>
                <p className="text-2xl font-bold text-purple-600">+12.5%</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}; 