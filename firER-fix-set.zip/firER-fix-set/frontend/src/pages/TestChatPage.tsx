import { useEffect, useState } from 'react';
import { CloudProvider, Prompt } from '../types';
import * as promptService from '../services/promptService';
import { useProvider } from '../contexts/ProviderContext';
import { AppLayout } from '../components/AppLayout';
import toast from 'react-hot-toast';
import logger from '../lib/logger';

export function TestChatPage() {
  const { 
    activeProvider, 
    setActiveProvider: changeActiveProvider,
    hasAccess,
    isLoading: isProviderLoading 
  } = useProvider();

  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load prompts when provider changes or when provider loading state changes
  useEffect(() => {
    const loadPrompts = async () => {
      if (isProviderLoading) {
        return; // Don't load prompts while provider data is still loading
      }
      
      try {
        setIsLoading(true);
        logger.log('TestChatPage - Loading prompts for provider:', activeProvider);
        
        // Use the same promptService as the Prompt Library
        const apiPrompts = await promptService.getPrompts(
          undefined, // No category filter
          activeProvider // Provider filter
        );
        
        logger.log('TestChatPage - Loaded prompts from API:', apiPrompts.length);
        setPrompts(apiPrompts);
        setError(null);
      } catch (err) {
        console.error('TestChatPage - Error loading prompts:', err);
        setError('Failed to load prompts. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };

    loadPrompts();
  }, [activeProvider, isProviderLoading]);

  // Handle provider change
  const handleProviderChange = (newProvider: CloudProvider) => {
    if (hasAccess(newProvider)) {
      changeActiveProvider(newProvider);
    } else {
      toast.error(`You don't have access to ${newProvider.toUpperCase()} resources`);
    }
  };

  // Handle category selection
  const handleCategorySelect = (category: string | null) => {
    setSelectedCategory(category);
  };

  // Handle prompt selection
  const handlePromptSelect = (prompt: Prompt) => {
    // Handle prompt selection logic here
    console.log('Selected prompt:', prompt);
  };

  // Get unique categories from prompts
  const categories = [...new Set(prompts.map(prompt => prompt.category))];
  
  // Filter prompts by selected category
  const filteredPrompts = selectedCategory
    ? prompts.filter(prompt => prompt.category === selectedCategory)
    : prompts;

  const providerAccess = {
    aws: hasAccess('aws'),
    azure: hasAccess('azure'),
    gcp: hasAccess('gcp'),
    onprem: hasAccess('onprem')
  };

  if (isProviderLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-full">
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-red-500">{error}</div>
          </div>
        ) : (
          <div className="flex-1 overflow-auto">
            <div className="h-full p-4 md:p-6">
              <div className="max-w-6xl mx-auto">
                <h1 className="text-2xl font-bold mb-4">Test Chat Page</h1>
                <p className="mb-4">This is a test page to verify prompt cards are loading correctly.</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {Object.entries(providerAccess).map(([provider, hasAccess]) => (
                    <button
                      key={provider}
                      onClick={() => handleProviderChange(provider as CloudProvider)}
                      className={`px-4 py-2 rounded-md ${
                        activeProvider === provider
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      } ${!hasAccess ? 'opacity-50 cursor-not-allowed' : ''}`}
                      disabled={!hasAccess}
                    >
                      {provider.toUpperCase()}
                    </button>
                  ))}
                </div>
                <p className="mb-4">Provider: <strong>{activeProvider.toUpperCase()}</strong>, Loaded <strong>{prompts.length}</strong> prompts</p>
                
                <div className="flex overflow-x-auto space-x-2 pb-2 mb-4">
                  <button
                    onClick={() => handleCategorySelect(null)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap flex-shrink-0 ${
                      selectedCategory === null
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    All
                  </button>
                  {categories.map(category => (
                    <button
                      key={category}
                      onClick={() => handleCategorySelect(category)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap flex-shrink-0 ${
                        selectedCategory === category
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-6">
                  {filteredPrompts.map((promptItem) => (
                    <div key={promptItem.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <h4 className="font-medium text-gray-900">{promptItem.title}</h4>
                      <p className="mt-2 text-sm text-gray-600">
                        {promptItem.description.substring(0, 100)}{promptItem.description.length > 100 ? '...' : ''}
                      </p>
                      <div className="mt-3 flex justify-between items-center">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {promptItem.category}
                        </span>
                        <button
                          onClick={() => handlePromptSelect(promptItem)}
                          className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                        >
                          Use Prompt
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
