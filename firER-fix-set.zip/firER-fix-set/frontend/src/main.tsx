import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider } from 'react-router-dom';
import { router } from './router';
import { Toaster } from 'react-hot-toast';
import './index.css';

// Import and setup Axios interceptors for global error handling
import { setupAxiosInterceptors } from './lib/axios-interceptor';

// Import the ProviderProvider
import { ProviderProvider } from './contexts/ProviderContext';
import { NavigationProvider } from './contexts/NavigationContext';
import { ProviderAccessProvider } from './contexts/ProviderAccessContext';

// Initialize Axios interceptors
setupAxiosInterceptors();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ProviderAccessProvider>
      <ProviderProvider>
        <NavigationProvider>
          <RouterProvider router={router} future={{ v7_startTransition: true }} />
          <Toaster position="top-right" />
        </NavigationProvider>
      </ProviderProvider>
    </ProviderAccessProvider>
  </StrictMode>
);