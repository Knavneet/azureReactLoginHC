-- PostgreSQL Database Dump
-- Generated from IntelliOps SQLAlchemy models
-- Created: 2025-08-20T10:17:43.149187

-- Database: intelliops_ai
-- Compatible with PostgreSQL 12+

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Create database if it doesn't exist
-- CREATE DATABASE intelliops_ai;
-- \c intelliops_ai;

-- Drop existing tables (uncomment if needed)
-- DROP TABLE IF EXISTS "users" CASCADE;
-- DROP TABLE IF EXISTS "user_roles" CASCADE;
-- DROP TABLE IF EXISTS "roles" CASCADE;
-- DROP TABLE IF EXISTS "role_permissions" CASCADE;
-- DROP TABLE IF EXISTS "provider_configs" CASCADE;
-- DROP TABLE IF EXISTS "provider_access" CASCADE;
-- DROP TABLE IF EXISTS "prompts" CASCADE;
-- DROP TABLE IF EXISTS "navigation_items" CASCADE;
-- DROP TABLE IF EXISTS "gcp_settings" CASCADE;
-- DROP TABLE IF EXISTS "favorite_prompts" CASCADE;
-- DROP TABLE IF EXISTS "chat_threads" CASCADE;
-- DROP TABLE IF EXISTS "chat_messages" CASCADE;
-- DROP TABLE IF EXISTS "aws_settings" CASCADE;
-- DROP TABLE IF EXISTS "api_logs" CASCADE;

-- Create tables

-- Table: api_logs
CREATE TABLE "api_logs" (
    "id" INTEGER PRIMARY KEY,
    "timestamp" TIMESTAMP WITH TIME ZONE,
    "log_type" VARCHAR(50) NOT NULL,
    "provider" VARCHAR(50) NOT NULL,
    "session_id" VARCHAR(255),
    "endpoint" VARCHAR(255),
    "request_data" JSON,
    "response_data" JSON,
    "status_code" INTEGER,
    "duration_ms" INTEGER,
    "error_message" TEXT
);

-- Table: aws_settings
CREATE TABLE "aws_settings" (
    "id" INTEGER PRIMARY KEY,
    "agent_id" VARCHAR(50) NOT NULL,
    "agent_alias_id" VARCHAR(50) NOT NULL,
    "is_active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE
);

-- Table: chat_messages
CREATE TABLE "chat_messages" (
    "id" INTEGER PRIMARY KEY,
    "thread_id" INTEGER NOT NULL,
    "role" VARCHAR(20) NOT NULL,
    "content" TEXT NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_chat_messages_id FOREIGN KEY ("thread_id") REFERENCES "chat_threads" ("id") ON DELETE CASCADE
);

-- Table: chat_threads
CREATE TABLE "chat_threads" (
    "id" INTEGER PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "title" VARCHAR(255),
    "cloud_provider" VARCHAR(32),
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_chat_threads_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

-- Table: favorite_prompts
CREATE TABLE "favorite_prompts" (
    "id" INTEGER PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "prompt_id" VARCHAR(64) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_favorite_prompts_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE,
    CONSTRAINT fk_favorite_prompts_id FOREIGN KEY ("prompt_id") REFERENCES "prompts" ("id") ON DELETE CASCADE
);

-- Table: gcp_settings
CREATE TABLE "gcp_settings" (
    "id" INTEGER PRIMARY KEY,
    "session_endpoint" VARCHAR(255) NOT NULL,
    "agent_run_endpoint" VARCHAR(255) NOT NULL,
    "is_active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE
);

-- Table: navigation_items
CREATE TABLE "navigation_items" (
    "id" VARCHAR(50) PRIMARY KEY,
    "title" VARCHAR(100) NOT NULL,
    "path" VARCHAR(255) NOT NULL,
    "tooltip" VARCHAR(255),
    "position" VARCHAR(20) NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,
    "is_enabled" BOOLEAN DEFAULT TRUE,
    "required_role" VARCHAR(50),
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE
);

-- Table: prompts
CREATE TABLE "prompts" (
    "id" VARCHAR(64) PRIMARY KEY,
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "category" VARCHAR(100),
    "command" TEXT NOT NULL,
    "cloud_provider" VARCHAR(32),
    "user_id" INTEGER,
    "is_system" BOOLEAN DEFAULT FALSE,
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_prompts_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE SET NULL
);

-- Table: provider_access
CREATE TABLE "provider_access" (
    "id" INTEGER PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "provider" VARCHAR(32) NOT NULL,
    "has_access" BOOLEAN DEFAULT TRUE,
    "is_active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_provider_access_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

-- Table: provider_configs
CREATE TABLE "provider_configs" (
    "id" INTEGER PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "provider" VARCHAR(32) NOT NULL,
    "config" JSON NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_provider_configs_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

-- Table: role_permissions
CREATE TABLE "role_permissions" (
    "id" INTEGER PRIMARY KEY,
    "role_id" INTEGER NOT NULL,
    "permission" VARCHAR(100) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_role_permissions_id FOREIGN KEY ("role_id") REFERENCES "roles" ("id") ON DELETE CASCADE
);

-- Table: roles
CREATE TABLE "roles" (
    "id" INTEGER PRIMARY KEY,
    "name" VARCHAR(50) NOT NULL UNIQUE,
    "description" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE
);

-- Table: user_roles
CREATE TABLE "user_roles" (
    "id" INTEGER PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "role_id" INTEGER NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE,
    CONSTRAINT fk_user_roles_id FOREIGN KEY ("role_id") REFERENCES "roles" ("id") ON DELETE CASCADE,
    CONSTRAINT fk_user_roles_id FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

-- Table: users
CREATE TABLE "users" (
    "id" INTEGER PRIMARY KEY,
    "name" VARCHAR(100) NOT NULL,
    "email" VARCHAR(100) NOT NULL UNIQUE,
    "hashed_password" VARCHAR(128) NOT NULL,
    "is_admin" BOOLEAN DEFAULT FALSE,
    "is_authenticated" BOOLEAN DEFAULT TRUE,
    "is_active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE,
    "updated_at" TIMESTAMP WITH TIME ZONE
);

-- Create sequences

CREATE SEQUENCE IF NOT EXISTS api_logs_id_seq;
ALTER TABLE "api_logs" ALTER COLUMN "id" SET DEFAULT nextval('api_logs_id_seq');

CREATE SEQUENCE IF NOT EXISTS aws_settings_id_seq;
ALTER TABLE "aws_settings" ALTER COLUMN "id" SET DEFAULT nextval('aws_settings_id_seq');

CREATE SEQUENCE IF NOT EXISTS chat_messages_id_seq;
ALTER TABLE "chat_messages" ALTER COLUMN "id" SET DEFAULT nextval('chat_messages_id_seq');

CREATE SEQUENCE IF NOT EXISTS chat_threads_id_seq;
ALTER TABLE "chat_threads" ALTER COLUMN "id" SET DEFAULT nextval('chat_threads_id_seq');

CREATE SEQUENCE IF NOT EXISTS favorite_prompts_id_seq;
ALTER TABLE "favorite_prompts" ALTER COLUMN "id" SET DEFAULT nextval('favorite_prompts_id_seq');

CREATE SEQUENCE IF NOT EXISTS gcp_settings_id_seq;
ALTER TABLE "gcp_settings" ALTER COLUMN "id" SET DEFAULT nextval('gcp_settings_id_seq');

CREATE SEQUENCE IF NOT EXISTS provider_access_id_seq;
ALTER TABLE "provider_access" ALTER COLUMN "id" SET DEFAULT nextval('provider_access_id_seq');

CREATE SEQUENCE IF NOT EXISTS provider_configs_id_seq;
ALTER TABLE "provider_configs" ALTER COLUMN "id" SET DEFAULT nextval('provider_configs_id_seq');

CREATE SEQUENCE IF NOT EXISTS role_permissions_id_seq;
ALTER TABLE "role_permissions" ALTER COLUMN "id" SET DEFAULT nextval('role_permissions_id_seq');

CREATE SEQUENCE IF NOT EXISTS roles_id_seq;
ALTER TABLE "roles" ALTER COLUMN "id" SET DEFAULT nextval('roles_id_seq');

CREATE SEQUENCE IF NOT EXISTS user_roles_id_seq;
ALTER TABLE "user_roles" ALTER COLUMN "id" SET DEFAULT nextval('user_roles_id_seq');

CREATE SEQUENCE IF NOT EXISTS users_id_seq;
ALTER TABLE "users" ALTER COLUMN "id" SET DEFAULT nextval('users_id_seq');

-- Insert data

-- Update sequences to current max values

SELECT setval('api_logs_id_seq', COALESCE((SELECT MAX("id") FROM "api_logs"), 1));
SELECT setval('aws_settings_id_seq', COALESCE((SELECT MAX("id") FROM "aws_settings"), 1));
SELECT setval('chat_messages_id_seq', COALESCE((SELECT MAX("id") FROM "chat_messages"), 1));
SELECT setval('chat_threads_id_seq', COALESCE((SELECT MAX("id") FROM "chat_threads"), 1));
SELECT setval('favorite_prompts_id_seq', COALESCE((SELECT MAX("id") FROM "favorite_prompts"), 1));
SELECT setval('gcp_settings_id_seq', COALESCE((SELECT MAX("id") FROM "gcp_settings"), 1));
SELECT setval('provider_access_id_seq', COALESCE((SELECT MAX("id") FROM "provider_access"), 1));
SELECT setval('provider_configs_id_seq', COALESCE((SELECT MAX("id") FROM "provider_configs"), 1));
SELECT setval('role_permissions_id_seq', COALESCE((SELECT MAX("id") FROM "role_permissions"), 1));
SELECT setval('roles_id_seq', COALESCE((SELECT MAX("id") FROM "roles"), 1));
SELECT setval('user_roles_id_seq', COALESCE((SELECT MAX("id") FROM "user_roles"), 1));
SELECT setval('users_id_seq', COALESCE((SELECT MAX("id") FROM "users"), 1));

-- End of dump