from fastapi import Depends, HTTPException, status, Request, Cookie
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone
import os
import logging
from dotenv import load_dotenv
from typing import Optional

# Set up logger
logger = logging.getLogger("backend.dependencies")

from .database import get_db
from . import models
from . import schemas
from . import crud
# Import directly from utils.py
import os

load_dotenv()

# JWT Settings from environment variables
SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = os.getenv("ALGORITHM", "HS256")

# Ensure SECRET_KEY is available
if not SECRET_KEY:
    logger.error("SECRET_KEY not found in environment variables. This is a critical security issue.")
    raise ValueError("SECRET_KEY environment variable must be set for secure JWT operations")

# Custom OAuth2 scheme that reads from cookies
class OAuth2PasswordBearerCookie(OAuth2PasswordBearer):
    def __init__(self, tokenUrl: str, scheme_name: Optional[str] = None, scopes: Optional[dict] = None, auto_error: bool = True):
        super().__init__(tokenUrl=tokenUrl, scheme_name=scheme_name, scopes=scopes, auto_error=auto_error)

    async def __call__(self, request: Request) -> Optional[str]:
        # First try to get token from cookie
        token = request.cookies.get("access_token")
        
        # Fallback to Authorization header for backward compatibility
        if not token:
            authorization = request.headers.get("Authorization")
            if authorization:
                scheme, _, param = authorization.partition(" ")
                if scheme.lower() == "bearer":
                    token = param
        
        if not token and self.auto_error:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return token

# Use the custom OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearerCookie(tokenUrl="/api/auth/login")

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={"message": "Session expired", "code": "TOKEN_EXPIRED"},
        headers={
            "WWW-Authenticate": "Bearer",
            "X-Error-Type": "token_expired"
        }
    )
    try:
        logger.info(f"Attempting to decode token: {token[:20]}...")
        logger.info(f"Using SECRET_KEY length: {len(SECRET_KEY) if SECRET_KEY else 0}")
        logger.info(f"Using ALGORITHM: {ALGORITHM}")
        
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        logger.info(f"Token decoded successfully: {payload}")
        
        email: str = payload.get("sub")
        if email is None:
            logger.error("No 'sub' field in token payload")
            raise credentials_exception
        token_data = schemas.TokenData(email=email)
    except JWTError as e:
        logger.error(f"JWT Error during token verification: {e}")
        logger.error(f"Token that failed: {token}")
        logger.error(f"SECRET_KEY available: {bool(SECRET_KEY)}")
        raise credentials_exception

    user = crud.get_user_by_email(db, email=token_data.email)
    if user is None:
        logger.error(f"User not found for email: {token_data.email}")
        raise credentials_exception
    
    # Check user roles to determine admin status
    if not user.is_admin:
        user_roles = crud.get_user_roles(db, user_id=user.id)
        for user_role in user_roles:
            role = crud.get_role(db, role_id=user_role.role_id)
            if role and role.name.lower() == 'admin':
                user.is_admin = True
                break

    logger.info(f"User authenticated successfully: {user.email}")
    return user

async def get_current_active_user(current_user: models.User = Depends(get_current_user)):
    # Check if user is authenticated
    if not current_user.is_authenticated:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    # Check if user is active (not soft deleted)
    if not current_user.is_active:
        print(f"[get_current_active_user] Attempt to access API by deactivated user: {current_user.email}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account has been deactivated. Please contact an administrator."
        )
    
    return current_user

def get_current_admin_user(current_user: models.User = Depends(get_current_active_user)):
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="The user doesn't have admin privileges"
        )
    return current_user

# RBAC utility functions
def get_user_permissions(db: Session, user_id: int):
    # Get all permissions from user's roles
    permissions = {}
    
    # Get user's roles
    user_roles = crud.get_user_roles(db, user_id=user_id)
    
    # For each role, get permissions
    for user_role in user_roles:
        role_permissions = crud.get_role_permissions(db, role_id=user_role.role_id)
        for perm in role_permissions:
            permissions[perm.permission] = True
    
    return permissions

def has_permission(permission: str, current_user: models.User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    # Admin users have all permissions
    if current_user.is_admin:
        return True
    
    # Get user permissions
    permissions = get_user_permissions(db, current_user.id)
    
    # Check if user has the required permission
    return permissions.get(permission, False)

# Permission dependency factories
def require_permission(permission: str):
    def permission_dependency(current_user: models.User = Depends(get_current_active_user), db: Session = Depends(get_db)):
        if not has_permission(permission, current_user, db):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"User does not have the required permission: {permission}"
            )
        return current_user
    return permission_dependency

# Provider access dependency
def has_provider_access(provider: str, current_user: models.User = Depends(get_current_active_user), db: Session = Depends(get_db)):
    # All users (including admins) must have explicit provider access set via RBAC
    # Admin status doesn't automatically grant provider access
    
    # Check if user has access to the provider
    provider_access = crud.get_provider_access_by_provider(db, user_id=current_user.id, provider=provider)
    return provider_access is not None and provider_access.has_access and provider_access.is_active

# Provider access dependency factory
def require_provider_access(provider: str):
    def provider_dependency(current_user: models.User = Depends(get_current_active_user), db: Session = Depends(get_db)):
        if not has_provider_access(provider, current_user, db):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"User does not have access to provider: {provider}"
            )
        return current_user
    return provider_dependency
