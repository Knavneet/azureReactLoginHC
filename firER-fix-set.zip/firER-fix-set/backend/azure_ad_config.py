from pydantic_settings import BaseSettings
from typing import Optional

class AzureAdSettings(BaseSettings):
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    tenant_id: Optional[str] = None
    redirect_uri: Optional[str] = "http://localhost:8000/get_token"

    class Config:
        env_prefix = "AZURE_AD_"

    @property
    def is_configured(self) -> bool:
        return all([self.client_id, self.client_secret, self.tenant_id])

    @property
    def authority(self) -> Optional[str]:
        if self.tenant_id:
            return f"https://login.microsoftonline.com/{self.tenant_id}"
        return None

azure_ad_config = AzureAdSettings()
