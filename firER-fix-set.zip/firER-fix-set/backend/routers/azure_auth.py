from fastapi import APIRouter, Depends, HTTPException, status, Response, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from msal import ConfidentialClientApplication
import requests
from datetime import timedelta
import uuid
import logging
from typing import Optional

from ..database import get_db
from .. import crud, models, schemas
from ..dependencies import create_access_token
from ..azure_ad_config import azure_ad_config
import os

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/auth/azure",
    tags=["Azure AD Auth"],
)

callback_router = APIRouter(
    tags=["Azure AD Auth"],
)

# Initialize MSAL app if Azure AD is configured
msal_app = None
if azure_ad_config.is_configured:
    msal_app = ConfidentialClientApplication(
        azure_ad_config.client_id,
        authority=azure_ad_config.authority,
        client_credential=azure_ad_config.client_secret,
    )
    logger.info("MSAL application initialized successfully")
else:
    logger.warning("Azure AD not configured. MSAL application not initialized.")


@router.get("/login")
async def azure_login():
    """Initiate Azure AD login flow"""
    if not azure_ad_config.is_configured:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Azure AD is not configured"
        )

    # Generate a random state for CSRF protection
    state = str(uuid.uuid4())

    # Get the authorization URL
    # Use User.Read scope only - reserved scopes (openid, profile) are added automatically
    auth_url = msal_app.get_authorization_request_url(
        scopes=["User.Read"],
        state=state,
        redirect_uri=azure_ad_config.redirect_uri
    )

    return {"auth_url": auth_url, "state": state}


@callback_router.get("/get_token")
async def azure_callback(
    request: Request,
    response: Response,
    code: str,
    state: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Handle Azure AD callback and create user session"""
    if not azure_ad_config.is_configured:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Azure AD is not configured"
        )

    try:
        # Exchange authorization code for token
        result = msal_app.acquire_token_by_authorization_code(
            code,
            scopes=["User.Read"],
            redirect_uri=azure_ad_config.redirect_uri
        )

        if "access_token" not in result:
            logger.error(f"Failed to acquire token: {result.get('error_description', 'Unknown error')}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result.get("error_description", "Failed to acquire token")
            )

        # Get user information from Microsoft Graph
        graph_response = requests.get(
            "https://graph.microsoft.com/v1.0/me",
            headers={"Authorization": f"Bearer {result['access_token']}"}
        )

        if graph_response.status_code != 200:
            logger.error(f"Failed to get user info from Graph API: {graph_response.text}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to get user information"
            )

        user_info = graph_response.json()
        email = user_info.get("mail") or user_info.get("userPrincipalName")
        name = user_info.get("displayName", email.split("@")[0] if email else "User")

        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Could not retrieve email from Azure AD"
            )

        # Check if user exists in database
        user = crud.get_user_by_email(db, email=email)
        is_new_user = user is None

        if not user:
            # Create new user with Azure AD info
            user_create = schemas.UserCreate(
                email=email,
                name=name,
                password=str(uuid.uuid4()),  # Random password for Azure AD users
                is_azure_ad_user=True
            )
            user = crud.create_user(db=db, user=user_create)
            logger.info(f"Created new Azure AD user: {email}")

            # Assign default role to new Azure AD user
            try:
                # TODO: Make the default role name configurable
                default_role_name = "User"
                user_role = crud.get_role_by_name(db, name=default_role_name)
                if user_role:
                    user_role_create = schemas.UserRoleCreate(user_id=user.id, role_id=user_role.id)
                    crud.create_user_role(db, user_role=user_role_create)
                    logger.info(f"Assigned default role '{default_role_name}' to new user: {email}")
                else:
                    logger.warning(f"Default role '{default_role_name}' not found. Skipping role assignment for new user: {email}")
            except Exception as e:
                logger.error(f"Failed to assign default role to new user {email}: {e}")


            # Give new Azure AD users default AWS provider access
            try:
                aws_access = models.ProviderAccess(
                    user_id=user.id,
                    provider="aws",
                    has_access=True,
                    is_active=True
                )
                db.add(aws_access)
                db.commit()
                logger.info(f"Granted default AWS provider access to new user: {email}")
            except Exception as e:
                logger.error(f"Failed to create AWS provider access for {email}: {e}")
                # Don't fail the login process for this error
        else:
            # Mark as existing user
            user._existing_user = True
            # Update user info if needed
            if not user.is_azure_ad_user:
                user.is_azure_ad_user = True
                db.commit()
                db.refresh(user)
                logger.info(f"Updated existing user to Azure AD user: {email}")

            # Ensure existing Azure AD user has a default role if they don't have one
            try:
                user_roles = crud.get_user_roles(db, user_id=user.id)
                if not user_roles:
                    default_role_name = "User"
                    user_role = crud.get_role_by_name(db, name=default_role_name)
                    if user_role:
                        user_role_create = schemas.UserRoleCreate(user_id=user.id, role_id=user_role.id)
                        crud.create_user_role(db, user_role=user_role_create)
                        logger.info(f"Assigned default role '{default_role_name}' to existing user: {email}")
                    else:
                        logger.warning(f"Default role '{default_role_name}' not found. Skipping role assignment for existing user: {email}")
            except Exception as e:
                logger.error(f"Failed to assign default role to existing user {email}: {e}")

        # Check if user is active
        if not user.is_active:
            logger.warning(f"Login attempt by deactivated Azure AD user: {user.email}")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account has been deactivated. Please contact an administrator."
            )

        # Generate access token
        access_token_expires = timedelta(minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30)))
        access_token = create_access_token(
            data={"sub": user.email}, expires_delta=access_token_expires
        )

        # Set httpOnly cookie
        is_development = os.getenv("ENVIRONMENT", "production").lower() in ["development", "dev", "local"]

        response.set_cookie(
            key="access_token",
            value=access_token,
            max_age=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30)) * 60,
            httponly=True,
            secure=not is_development,
            samesite="lax",
        )

        logger.info(f"Azure AD user logged in successfully: {email}")

        # Always redirect to /chat as the landing page
        frontend_url = os.getenv("FRONTEND_URL", "http://localhost:5173")
        redirect_response = RedirectResponse(url=f"{frontend_url}/chat")

        logger.info(f"Redirecting {'new' if is_new_user else 'existing'} Azure AD user {email} to /chat")

        # Set the same cookie on the redirect response
        redirect_response.set_cookie(
            key="access_token",
            value=access_token,
            max_age=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30)) * 60,
            httponly=True,
            secure=not is_development,
            samesite="lax",
        )

        return redirect_response

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error during Azure AD callback: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred during Azure AD authentication"
        )


@router.get("/status")
async def azure_ad_status():
    """Check Azure AD configuration status"""
    return {
        "configured": azure_ad_config.is_configured,
        "tenant_id": azure_ad_config.tenant_id is not None,
        "client_id": azure_ad_config.client_id is not None,
        "client_secret": azure_ad_config.client_secret is not None,
        "redirect_uri": azure_ad_config.redirect_uri
    }


@router.post("/token/validate")
async def validate_azure_token(
    token: str,
    db: Session = Depends(get_db)
):
    """Validate an Azure AD token (for testing purposes)"""
    if not azure_ad_config.is_configured:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Azure AD is not configured"
        )

    try:
        # Validate token with Microsoft Graph
        graph_response = requests.get(
            "https://graph.microsoft.com/v1.0/me",
            headers={"Authorization": f"Bearer {token}"}
        )

        if graph_response.status_code == 200:
            user_info = graph_response.json()
            return {
                "valid": True,
                "user_info": {
                    "email": user_info.get("mail") or user_info.get("userPrincipalName"),
                    "name": user_info.get("displayName"),
                    "id": user_info.get("id")
                }
            }
        else:
            return {
                "valid": False,
                "error": "Invalid token"
            }

    except Exception as e:
        logger.error(f"Error validating token: {str(e)}")
        return {
            "valid": False,
            "error": str(e)
        }