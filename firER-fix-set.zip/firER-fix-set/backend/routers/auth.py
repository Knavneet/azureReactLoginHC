from fastapi import APIRouter, Depends, HTTPException, status, Response
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from sqlalchemy.orm import Session
from datetime import timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
import os

# Create password context directly in this file to avoid circular imports
pwd_context = CryptContext(schemes=["sha256_crypt"], deprecated="auto")

# Define password verification function directly
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

from .. import crud, models, schemas, utils
from ..database import get_db
from ..dependencies import create_access_token, get_current_active_user, get_current_user

router = APIRouter(
    prefix="/auth",
    tags=["auth"],
)

ACCESS_TOKEN_EXPIRE_MINUTES = 30 # Or load from config

@router.post("/register", response_model=schemas.User)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)

@router.post("/login")
def login_for_access_token(
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(), 
    db: Session = Depends(get_db)
):
    # Get user by email
    user = crud.get_user_by_email(db, email=form_data.username) # Use email as username
    
    # Check if user exists and password is correct
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user is active (not soft deleted)
    if not user.is_active:
        print(f"[login] Login attempt by deactivated user: {user.email}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account has been deactivated. Please contact an administrator.",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    # Check user roles to determine admin status
    is_admin = user.is_admin
    if not is_admin:
        user_roles = crud.get_user_roles(db, user_id=user.id)
        for user_role in user_roles:
            role = crud.get_role(db, role_id=user_role.role_id)
            if role and role.name.lower() == 'admin':
                is_admin = True
                break

    # Generate access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    
    # Determine if we're in development (allow HTTP cookies)
    is_development = os.getenv("ENVIRONMENT", "production").lower() in ["development", "dev", "local"]
    
    # Set httpOnly cookie for secure token storage
    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,  # Convert to seconds
        httponly=True,  # Prevents XSS attacks
        secure=not is_development,  # Only require HTTPS in production
        samesite="lax",  # CSRF protection
        # Don't set domain for localhost to avoid .localhost prefix
    )
    
    # Return user information without the token
    return {
        "message": "Login successful",
        "user": {
            "id": user.id,
            "email": user.email,
            "name": user.name,
            "is_admin": is_admin,
            "is_authenticated": True
        }
    }

@router.post("/logout")
def logout(response: Response):
    """Logout by clearing the httpOnly cookie"""
    # Determine if we're in development
    is_development = os.getenv("ENVIRONMENT", "production").lower() in ["development", "dev", "local"]
    
    response.delete_cookie(
        key="access_token",
        httponly=True,
        secure=not is_development,
        samesite="lax",
        # Don't set domain for localhost to avoid .localhost prefix
    )
    return {"message": "Logout successful"}

# Add password reset endpoints later

@router.post("/refresh", response_model=schemas.Token)
def refresh_token(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Create a new access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": current_user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}
