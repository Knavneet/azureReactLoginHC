import os
from typing import List, Set
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class ProviderConfig:
    """Configuration for cloud providers"""
    
    # All available providers
    ALL_PROVIDERS = {'aws', 'azure', 'gcp', 'onprem'}
    
    @classmethod
    def get_enabled_providers(cls) -> Set[str]:
        """
        Get the list of enabled providers from environment variables.
        
        Supports two configuration methods:
        1. ENABLED_PROVIDERS=aws,gcp,azure (comma-separated list)
        2. Individual flags: ENABLE_AWS_PROVIDER=true, ENABLE_GCP_PROVIDER=true, etc.
        
        Returns:
            Set of enabled provider names
        """
        # Method 1: Check for comma-separated list
        enabled_providers_str = os.getenv("ENABLED_PROVIDERS", "").strip()
        if enabled_providers_str:
            providers = {p.strip().lower() for p in enabled_providers_str.split(",") if p.strip()}
            # Validate providers
            valid_providers = providers.intersection(cls.ALL_PROVIDERS)
            if valid_providers:
                return valid_providers
        
        # Method 2: Check individual environment variables
        enabled_providers = set()
        
        if os.getenv("ENABLE_AWS_PROVIDER", "").lower() == "true":
            enabled_providers.add("aws")
        if os.getenv("ENABLE_AZURE_PROVIDER", "").lower() == "true":
            enabled_providers.add("azure")
        if os.getenv("ENABLE_GCP_PROVIDER", "").lower() == "true":
            enabled_providers.add("gcp")
        if os.getenv("ENABLE_ONPREM_PROVIDER", "").lower() == "true":
            enabled_providers.add("onprem")
        
        # If no providers are explicitly enabled, default to all providers
        if not enabled_providers:
            return cls.ALL_PROVIDERS.copy()
        
        return enabled_providers
    
    @classmethod
    def is_provider_enabled(cls, provider: str) -> bool:
        """Check if a specific provider is enabled"""
        return provider.lower() in cls.get_enabled_providers()
    
    @classmethod
    def get_enabled_providers_list(cls) -> List[str]:
        """Get enabled providers as a sorted list"""
        return sorted(list(cls.get_enabled_providers()))

# Create a global instance for easy access
provider_config = ProviderConfig() 