import requests
import json

# Test with wrong credentials
print("=== Testing with WRONG credentials ===")
try:
    response = requests.post(
        'http://localhost:8000/api/auth/login',
        data={'username': 'wrong@email.com', 'password': 'wrongpassword'}
    )
    print(f"Status Code: {response.status_code}")
    print(f"Response Text: {response.text}")
    
    if response.headers.get('content-type', '').startswith('application/json'):
        try:
            json_response = response.json()
            print(f"JSON Response: {json.dumps(json_response, indent=2)}")
        except:
            print("Failed to parse JSON")
    
except Exception as e:
    print(f"Error: {e}")

print("\n=== Testing with CORRECT credentials ===")
try:
    response = requests.post(
        'http://localhost:8000/api/auth/login',
        data={'username': 'jaideep12986@gmail.com', 'password': 'postgres123'}
    )
    print(f"Status Code: {response.status_code}")
    print(f"Response Text: {response.text}")
    
    if response.headers.get('content-type', '').startswith('application/json'):
        try:
            json_response = response.json()
            print(f"JSON Response: {json.dumps(json_response, indent=2)}")
        except:
            print("Failed to parse JSON")
    
except Exception as e:
    print(f"Error: {e}") 