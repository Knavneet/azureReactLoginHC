import axios, { AxiosInstance } from 'axios';
import { Prompt } from '../types';
import { API_BASE_URL } from '../config';
import { ENDPOINTS } from '../constants/appConstants';

// Create axios instance with base configuration
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true, // Important: include cookies for authentication
});

// Add response interceptor to handle errors, especially JWT expiration
apiClient.interceptors.response.use(
  response => response,
  error => {
    console.error('API error in promptService:', error);
    
    // Check if it's a 401 Unauthorized error
    if (error.response && error.response.status === 401) {
      // Get the error message
      const errorMessage = (error.response?.data?.detail || 
                         error.response?.data?.message || 
                         error.message || 
                         'Unauthorized').toString();
      
      console.log('401 error detected in promptService:', errorMessage);
      
      // Check if it's a JWT expiration error - use broader matching
      if (
        errorMessage.includes('JWT') || 
        errorMessage.includes('token') ||
        errorMessage.includes('signature') ||
        errorMessage.includes('expired') ||
        errorMessage.includes('validate credentials') ||
        errorMessage.includes('unauthorized')
      ) {
        console.log('JWT expiration detected in promptService, handling session expiration');
        
        // Clear auth data (tokens are handled by httpOnly cookies)
        localStorage.removeItem('currentUser');
        
        // Show toast notification
        import('react-hot-toast').then(toast => {
          toast.toast.error('Your session has expired. Please login again.', { duration: 5000 });
        });
        
        // Dispatch JWT expiration event
        window.dispatchEvent(new Event('jwt-expired'));
        
        // Force redirect to login page after a short delay
        setTimeout(() => {
          window.location.href = '/login';
        }, 1000);
      }
    }
    
    return Promise.reject(error);
  }
);

// Type for backend prompt that needs to be converted to frontend format
interface BackendPrompt {
  id: string;
  title: string;
  description: string;
  category: string;
  command: string;
  user_id: number | null;
  cloud_provider: string;
  is_system: boolean;
  is_favorite?: boolean;
  created_at: string;
  updated_at: string;
}

// Convert backend prompt to frontend format
const convertPrompt = (backendPrompt: BackendPrompt): Prompt => {
  return {
    id: backendPrompt.id,
    title: backendPrompt.title,
    description: backendPrompt.description || '',
    category: backendPrompt.category || 'General',
    command: backendPrompt.command,
    user_id: backendPrompt.user_id?.toString() || undefined,
    cloud_provider: backendPrompt.cloud_provider as any || 'aws',
    is_favorite: backendPrompt.is_favorite || false,
    is_system: backendPrompt.is_system || false
  };
};

// Get all prompts (user prompts + system prompts)
export const getPrompts = async (category?: string, cloudProvider?: string): Promise<Prompt[]> => {
  try {
    const params = new URLSearchParams();
    
    if (category && category !== 'all') {
      params.append('category', category);
    }
    
    if (cloudProvider && cloudProvider !== 'all') {
      params.append('cloud_provider', cloudProvider);
    }
    
    let url = '/api/prompts';
    if (params.toString()) {
      url += `?${params.toString()}`;
    }
    
    const response = await apiClient.get(url);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn('Unexpected response format for prompts:', response.data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching prompts:', error);
    throw error;
  }
};

// Get only system prompts
export const getSystemPrompts = async (category?: string, cloudProvider?: string): Promise<Prompt[]> => {
  try {
    const params = new URLSearchParams();
    
    if (category && category !== 'all') {
      params.append('category', category);
    }
    
    if (cloudProvider && cloudProvider !== 'all') {
      params.append('cloud_provider', cloudProvider);
    }
    
    let url = '/api/prompts/system';
    if (params.toString()) {
      url += `?${params.toString()}`;
    }
    
    const response = await apiClient.get(url);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn('Unexpected response format for system prompts:', response.data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching system prompts:', error);
    throw error;
  }
};

// Get only user prompts
export const getUserPrompts = async (category?: string, cloudProvider?: string): Promise<Prompt[]> => {
  try {
    const params = new URLSearchParams();
    
    if (category && category !== 'all') {
      params.append('category', category);
    }
    
    if (cloudProvider && cloudProvider !== 'all') {
      params.append('cloud_provider', cloudProvider);
    }
    
    let url = '/api/prompts/user';
    if (params.toString()) {
      url += `?${params.toString()}`;
    }
    
    const response = await apiClient.get(url);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn('Unexpected response format for user prompts:', response.data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching user prompts:', error);
    throw error;
  }
};

// Admin: Get all prompts in the system
export const getAllPromptsAdmin = async (category?: string, cloudProvider?: string): Promise<Prompt[]> => {
  try {
    const params = new URLSearchParams();
    
    if (category && category !== 'all') {
      params.append('category', category);
    }
    
    if (cloudProvider && cloudProvider !== 'all') {
      params.append('cloud_provider', cloudProvider);
    }
    
    let url = '/api/prompts/admin/all';
    if (params.toString()) {
      url += `?${params.toString()}`;
    }
    
    const response = await apiClient.get(url);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn('Unexpected response format for admin prompts:', response.data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching all prompts (admin):', error);
    throw error;
  }
};

// Get a specific prompt by ID
export const getPromptById = async (promptId: string): Promise<Prompt> => {
  try {
    const response = await apiClient.get(`/api/prompts/${promptId}`);
    return convertPrompt(response.data);
  } catch (error) {
    console.error(`Error fetching prompt ${promptId}:`, error);
    throw error;
  }
};

// Create a new prompt
export const createPrompt = async (promptData: Omit<Prompt, 'id'>): Promise<Prompt> => {
  try {
    console.log('Creating prompt with data:', promptData);
    
    // Convert frontend prompt to backend format
    const backendPromptData = {
      id: `prompt-${Date.now()}`, // Generate a unique ID
      title: promptData.title,
      description: promptData.description || '',
      category: promptData.category,
      command: promptData.command,
      cloud_provider: promptData.cloud_provider,
      is_system: promptData.is_system || false
    };
    
    console.log('Sending API request to create prompt:', backendPromptData);
    
    // Make the API request with explicit headers
    const response = await apiClient.post(`/api/prompts`, backendPromptData);
    
    console.log('Prompt created successfully:', response.data);
    return convertPrompt(response.data);
  } catch (error) {
    console.error('Error creating prompt:', error);
    
    throw error;
  }
};

// Update an existing prompt
export const updatePrompt = async (promptId: string, promptData: Partial<Prompt>): Promise<Prompt> => {
  try {
    // Convert frontend prompt to backend format
    const backendPromptData = {
      title: promptData.title,
      description: promptData.description,
      category: promptData.category,
      command: promptData.command,
      cloud_provider: promptData.cloud_provider
    };
    
    const response = await apiClient.put(`/api/prompts/${promptId}`, backendPromptData);
    return convertPrompt(response.data);
  } catch (error) {
    console.error(`Error updating prompt ${promptId}:`, error);
    throw error;
  }
};

// Delete a prompt
export const deletePrompt = async (promptId: string): Promise<void> => {
  try {
    await apiClient.delete(`/api/prompts/${promptId}`);
  } catch (error) {
    console.error(`Error deleting prompt ${promptId}:`, error);
    throw error;
  }
};

// Get user's favorite prompts
export const getFavoritePrompts = async (): Promise<Prompt[]> => {
  try {
    const response = await apiClient.get(`/api/favorite-prompts/details`);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn('Unexpected response format for favorite prompts:', response.data);
      return [];
    }
  } catch (error) {
    console.error('Error fetching favorite prompts:', error);
    throw error;
  }
};

// Check if a prompt is in favorites
export const checkIsFavorite = async (promptId: string): Promise<boolean> => {
  try {
    const response = await apiClient.get(`/api/favorite-prompts/${promptId}`);
    return response.data;
  } catch (error) {
    console.error(`Error checking if prompt ${promptId} is favorite:`, error);
    return false;
  }
};

// Add a prompt to favorites
export const addToFavorites = async (promptId: string): Promise<void> => {
  try {
    await apiClient.post(`/api/favorite-prompts`, { prompt_id: promptId });
  } catch (error: any) {
    // Check if it's a 400 error for "already in favorites"
    if (error.response?.status === 400 && error.response?.data?.detail?.includes('already in favorites')) {
      // Silently ignore this error - the prompt is already favorited
      console.log(`Prompt ${promptId} is already in favorites`);
      return;
    }
    console.error(`Error adding prompt ${promptId} to favorites:`, error);
    throw error;
  }
};

// Remove a prompt from favorites
export const removeFromFavorites = async (promptId: string): Promise<void> => {
  try {
    await apiClient.delete(`/api/favorite-prompts/${promptId}`);
  } catch (error) {
    console.error(`Error removing prompt ${promptId} from favorites:`, error);
    throw error;
  }
};

// Admin: Get favorite prompts for a specific user
export const getUserFavoritesAdmin = async (userId: number): Promise<Prompt[]> => {
  try {
    const response = await apiClient.get(`/api/favorite-prompts/admin/user/${userId}`);
    // Check if response.data is an array before mapping
    if (Array.isArray(response.data)) {
      return response.data.map(convertPrompt);
    } else {
      console.warn(`Unexpected response format for user ${userId} favorites:`, response.data);
      return [];
    }
  } catch (error) {
    console.error(`Error fetching favorites for user ${userId}:`, error);
    throw error;
  }
};
