/**
 * Authentication Service
 * Handles user authentication with the FastAPI backend
 */

import { User } from '../types';
import { authApi } from './api/auth';
import { AUTH_USER } from '../constants/storageKeys';

class AuthService {
  private user: User | null = null;
  private token: string | null = null;
  private listeners: ((user: User | null) => void)[] = [];

  constructor() {
    console.log('[AuthService] Initializing AuthService');
    this.loadSession();
  }

  /**
   * Load session from server (cookies are handled automatically)
   */
  private async loadSession() {
    console.log('[AuthService] Loading session');
    
    try {
      console.log('[AuthService] Validating session by fetching user profile');
      const userData = await authApi.getProfile();
      console.log('[AuthService] User profile fetched successfully:', userData);
      
      // Set the user data after successful validation
      this.user = userData;
      
      // Notify listeners after user is set
      this.notifyListeners();
      console.log('[AuthService] Listeners notified of authentication');
      return userData;
    } catch (error) {
      console.error('[AuthService] Error validating session:', error);
      
      const errorMessage = error instanceof Error && error.message ? error.message.toLowerCase() : '';
      const isTokenExpired = 
        errorMessage.includes('jwt') || 
        errorMessage.includes('token') || 
        errorMessage.includes('validate credentials') || 
        errorMessage.includes('signature has expired') || 
        errorMessage.includes('unauthorized');
        
      if (isTokenExpired) {
        console.log('[AuthService] Session appears to be expired or invalid, clearing session');
        this.user = null;
        this.notifyListeners();
        console.log('[AuthService] Session cleared due to token expiration');
        return null;
      }
      
      try {
        const localUser = JSON.parse(localStorage.getItem(AUTH_USER) || 'null');
        if (localUser) {
          console.log('[AuthService] Using fallback user data from localStorage for display only:', localUser);
          const fallbackUser = {
            id: 1,
            name: localUser.name || localUser.email.split('@')[0],
            email: localUser.email,
            is_admin: localUser.isAdmin || false,
            is_authenticated: false
          };
          this.user = fallbackUser;
          this.notifyListeners();
          console.log('[AuthService] Listeners notified with fallback user data');
          return fallbackUser;
        }
      } catch (fallbackError) {
        console.error('[AuthService] Error using fallback user data:', fallbackError);
      }
      
      this.user = null;
      this.notifyListeners();
      console.log('[AuthService] Listeners notified of authentication failure');
      return null;
    }
  }

  private saveSession(user: User) {
    this.user = user;
    localStorage.setItem(AUTH_USER, JSON.stringify(user));
    this.notifyListeners();
  }

  public onAuthStateChange(listener: (user: User | null) => void): () => void {
    this.listeners.push(listener);
    listener(this.user);
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    this.listeners.forEach(listener => {
      try {
        listener(this.user);
      } catch (error) {
        console.error('[AuthService] Error in auth state listener:', error);
      }
    });
  }

  public async refreshSession(): Promise<User | null> {
    console.log('[AuthService] Refreshing session');
    return await this.loadSession();
  }

  public async login(email: string, password: string) {
    try {
      console.log('[AuthService] Attempting login for:', email);
      const response = await authApi.login(email, password);
      console.log('[AuthService] Login successful, response received:', response);
      
      if (response.user) {
        console.log('[AuthService] User data received from login response:', response.user);
        this.user = {
          id: response.user.id,
          name: response.user.name || email.split('@')[0],
          email: response.user.email,
          is_admin: response.user.is_admin,
          is_authenticated: true
        };
        
        localStorage.setItem(AUTH_USER, JSON.stringify(this.user));
        this.notifyListeners();
        console.log('[AuthService] User set from login response:', this.user);
      } else {
        console.log('[AuthService] No user data in login response, fetching profile');
        await this.loadSession();
      }
      
      return response;
    } catch (error) {
      console.error('[AuthService] Login failed:', error);
      throw error;
    }
  }

  public async register(name: string, email: string, password: string) {
    try {
      console.log('[AuthService] Attempting registration for:', email);
      const response = await authApi.register(name, email, password);
      console.log('[AuthService] Registration successful:', response);
      return response;
    } catch (error) {
      console.error('[AuthService] Registration failed:', error);
      throw error;
    }
  }

  public async logout() {
    try {
      console.log('[AuthService] Logging out user');
      await authApi.logout();
      this.clearLocalSession();
      console.log('[AuthService] Logout successful');
      const currentPath = window.location.pathname + window.location.search;
      if (!['/login', '/register'].includes(window.location.pathname)) {
        sessionStorage.setItem('redirectAfterLogin', currentPath);
      }
      window.location.href = '/login';
    } catch (error) {
      console.error('[AuthService] Logout error:', error);
      this.clearLocalSession();
      const currentPath = window.location.pathname + window.location.search;
      if (!['/login', '/register'].includes(window.location.pathname)) {
        sessionStorage.setItem('redirectAfterLogin', currentPath);
      }
      window.location.href = '/login';
    }
  }

  public clearLocalSession() {
    console.log('[AuthService] Clearing local session data');
    this.user = null;
    localStorage.removeItem(AUTH_USER);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('selectedProvider');
    this.notifyListeners();
  }

  public getUser(): User | null {
    return this.user;
  }

  public getToken(): string | null {
    console.warn('[AuthService] getToken() is deprecated with httpOnly cookies. Tokens are handled automatically.');
    return null;
  }

  public isAuthenticated(): boolean {
    if (this.user && this.user.is_authenticated) {
      console.log('[AuthService] User is authenticated via session');
      return true;
    }
    console.log('[AuthService] User is not authenticated');
    return false;
  }

  public isAdmin(): boolean {
    return this.user?.is_admin || false;
  }
}

export const authService = new AuthService();