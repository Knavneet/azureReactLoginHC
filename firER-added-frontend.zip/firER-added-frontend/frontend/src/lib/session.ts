/**
 * Session management utilities
 * Updated to work with httpOnly cookies for secure authentication
 */

import { authService } from './auth-service';

/**
 * Check if user is authenticated
 */
export function isAuthenticated(): boolean {
  return authService.isAuthenticated();
}

/**
 * Get current user
 */
export function getCurrentUser() {
  return authService.getUser();
}

/**
 * Check if current user is admin
 */
export function isAdmin(): boolean {
  return authService.isAdmin();
}

/**
 * Logout user
 */
export async function logout() {
  await authService.logout();
}

/**
 * Refresh session
 */
export async function refreshSession() {
  return await authService.refreshSession();
}