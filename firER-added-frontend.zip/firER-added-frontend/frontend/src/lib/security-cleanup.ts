/**
 * Security cleanup utility to remove sensitive data from localStorage
 * This should be called on app initialization to ensure no passwords or sensitive data remain
 */

export class SecurityCleanup {
  /**
   * Remove all stored passwords and sensitive authentication data
   */
  static cleanupStoredPasswords(): void {
    try {
      // Remove any stored users array that might contain passwords
      const users = localStorage.getItem('users');
      if (users) {
        console.warn('[SecurityCleanup] Removing stored users array containing passwords');
        localStorage.removeItem('users');
      }

      // Remove any auth tokens that shouldn't be in localStorage
      const authToken = localStorage.getItem('auth_token');
      if (authToken) {
        console.warn('[SecurityCleanup] Removing auth token from localStorage');
        localStorage.removeItem('auth_token');
      }

      // Remove deprecated auth_user data
      const authUser = localStorage.getItem('auth_user');
      if (authUser) {
        console.warn('[SecurityCleanup] Removing deprecated auth_user data');
        localStorage.removeItem('auth_user');
      }

      // Clean up any other potentially sensitive keys
      const sensitiveKeys = [
        'password',
        'user_password',
        'admin_password',
        'credentials',
        'secret',
        'private_key',
        'api_key'
      ];

      sensitiveKeys.forEach(key => {
        if (localStorage.getItem(key)) {
          console.warn(`[SecurityCleanup] Removing sensitive key: ${key}`);
          localStorage.removeItem(key);
        }
      });

      console.log('[SecurityCleanup] Security cleanup completed');
    } catch (error) {
      console.error('[SecurityCleanup] Error during security cleanup:', error);
    }
  }

  /**
   * Validate that no sensitive data remains in localStorage
   */
  static validateSecurityCompliance(): boolean {
    try {
      const allKeys = Object.keys(localStorage);
      const sensitivePatterns = [
        /password/i,
        /secret/i,
        /private/i,
        /credential/i,
        /token/i // except for specific allowed tokens
      ];

      const allowedTokenKeys = [
        'selectedProvider',
        'selectedPromptCategory',
        'migration_complete',
        'migration_completed',
        'prompts_migrated',
        'chat_history_migrated',
        'provider_configs_migrated'
      ];

      const violations: string[] = [];

      allKeys.forEach(key => {
        // Skip allowed keys
        if (allowedTokenKeys.includes(key)) {
          return;
        }

        // Check for sensitive patterns
        const isSensitive = sensitivePatterns.some(pattern => pattern.test(key));
        if (isSensitive) {
          violations.push(key);
        }

        // Check for stored user data with passwords
        if (key === 'users') {
          try {
            const users = JSON.parse(localStorage.getItem(key) || '[]');
            if (Array.isArray(users) && users.some(user => user.password)) {
              violations.push(`${key} (contains passwords)`);
            }
          } catch (e) {
            // Ignore parsing errors
          }
        }
      });

      if (violations.length > 0) {
        console.error('[SecurityCleanup] Security violations found:', violations);
        return false;
      }

      console.log('[SecurityCleanup] Security compliance validated - no sensitive data found');
      return true;
    } catch (error) {
      console.error('[SecurityCleanup] Error during security validation:', error);
      return false;
    }
  }

  /**
   * Get a report of what data is currently stored in localStorage
   */
  static getStorageReport(): { key: string; size: number; type: string; sensitive: boolean }[] {
    try {
      const allKeys = Object.keys(localStorage);
      const sensitivePatterns = [
        /password/i,
        /secret/i,
        /private/i,
        /credential/i,
        /token/i
      ];

      return allKeys.map(key => {
        const value = localStorage.getItem(key) || '';
        const isSensitive = sensitivePatterns.some(pattern => pattern.test(key)) ||
                           (key === 'users' && value.includes('password'));

        return {
          key,
          size: value.length,
          type: this.detectDataType(value),
          sensitive: isSensitive
        };
      });
    } catch (error) {
      console.error('[SecurityCleanup] Error generating storage report:', error);
      return [];
    }
  }

  private static detectDataType(value: string): string {
    if (!value) return 'empty';
    
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return 'array';
      if (typeof parsed === 'object') return 'object';
      return typeof parsed;
    } catch {
      return 'string';
    }
  }
}

// Auto-cleanup on module load
SecurityCleanup.cleanupStoredPasswords(); 