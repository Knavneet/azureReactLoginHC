import { PublicClientApplication, Configuration, LogLevel } from "@azure/msal-browser";
import { AZURE_AD_CLIENT_ID, AZURE_AD_TENANT_ID, AZURE_AD_REDIRECT_URI } from "../config";

/**
 * MSAL configuration object.
 */
const msalConfig: Configuration = {
  auth: {
    clientId: AZURE_AD_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${AZURE_AD_TENANT_ID}`,
    redirectUri: AZURE_AD_REDIRECT_URI,
    postLogoutRedirectUri: AZURE_AD_REDIRECT_URI,
  },
  cache: {
    cacheLocation: "sessionStorage", // This is more secure than localStorage
    storeAuthStateInCookie: false, 
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

/**
 * MSAL instance to be used throughout the application.
 */
export const msalInstance = new PublicClientApplication(msalConfig);

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) for AAD v2.0 endpoints.
 */
export const loginRequest = {
  scopes: ["openid", "profile", "email"]
};
