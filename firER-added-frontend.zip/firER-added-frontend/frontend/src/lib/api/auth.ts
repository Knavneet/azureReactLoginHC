import { User } from '../../types';
import { API_BASE_URL } from '../../config';

interface LoginResponse {
  message: string;
  user: {
    id: number;
    email: string;
    name: string;
    is_admin: boolean;
    is_authenticated: boolean;
  };
}

interface RegisterResponse {
  id: number;
  email: string;
  name: string;
  is_admin: boolean;
}

class AuthAPI {
  private baseUrl: string;

  constructor() {
    this.baseUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
  }

  /**
   * Login with email and password
   * The server will set httpOnly cookies automatically
   */
  async login(email: string, password: string): Promise<LoginResponse> {
    const formData = new FormData();
    formData.append('username', email); // FastAPI OAuth2 expects 'username'
    formData.append('password', password);

    const response = await fetch(`${this.baseUrl}/api/auth/login`, {
      method: 'POST',
      body: formData,
      credentials: 'include', // Important: include cookies in requests
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      // Handle nested error structure
      let errorMessage = 'Login failed';
      if (errorData.detail) {
        if (typeof errorData.detail === 'string') {
          errorMessage = errorData.detail;
        } else if (errorData.detail.message) {
          errorMessage = errorData.detail.message;
        } else if (typeof errorData.detail === 'object') {
          errorMessage = JSON.stringify(errorData.detail);
        }
      }
      
      // Handle specific error cases
      if (response.status === 401) {
        errorMessage = 'Incorrect email or password. Please try again.';
      }
      
      throw new Error(errorMessage);
    }

    return response.json();
  }

  /**
   * Register a new user
   */
  async register(name: string, email: string, password: string): Promise<RegisterResponse> {
    const response = await fetch(`${this.baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        email,
        password,
      }),
      credentials: 'include',
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      // Handle nested error structure
      let errorMessage = 'Registration failed';
      if (errorData.detail) {
        if (typeof errorData.detail === 'string') {
          errorMessage = errorData.detail;
        } else if (errorData.detail.message) {
          errorMessage = errorData.detail.message;
        } else if (typeof errorData.detail === 'object') {
          errorMessage = JSON.stringify(errorData.detail);
        }
      }
      
      throw new Error(errorMessage);
    }

    return response.json();
  }

  /**
   * Get current user profile
   * Uses httpOnly cookies for authentication
   */
  async getProfile(): Promise<User> {
    const response = await fetch(`${this.baseUrl}/api/users/me`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include', // Include cookies
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      // Handle nested error structure
      let errorMessage = 'Failed to get profile';
      if (errorData.detail) {
        if (typeof errorData.detail === 'string') {
          errorMessage = errorData.detail;
        } else if (errorData.detail.message) {
          errorMessage = errorData.detail.message;
        } else if (typeof errorData.detail === 'object') {
          errorMessage = JSON.stringify(errorData.detail);
        }
      }
      
      throw new Error(errorMessage);
    }

    const userData = await response.json();
    
    // Convert backend format to frontend format
    return {
      id: userData.id,
      name: userData.name,
      email: userData.email,
      is_admin: userData.is_admin,
      is_authenticated: true,
    };
  }

  /**
   * Logout user
   * Clears httpOnly cookies on the server
   */
  async logout(): Promise<void> {
    const response = await fetch(`${this.baseUrl}/api/auth/logout`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      // Handle nested error structure
      let errorMessage = 'Logout failed';
      if (errorData.detail) {
        if (typeof errorData.detail === 'string') {
          errorMessage = errorData.detail;
        } else if (errorData.detail.message) {
          errorMessage = errorData.detail.message;
        } else if (typeof errorData.detail === 'object') {
          errorMessage = JSON.stringify(errorData.detail);
        }
      }
      
      throw new Error(errorMessage);
    }
  }

  /**
   * Refresh token (not needed with httpOnly cookies, but kept for compatibility)
   */
  async refreshToken(): Promise<{ access_token: string; token_type: string }> {
    const response = await fetch(`${this.baseUrl}/api/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      // Handle nested error structure
      let errorMessage = 'Token refresh failed';
      if (errorData.detail) {
        if (typeof errorData.detail === 'string') {
          errorMessage = errorData.detail;
        } else if (errorData.detail.message) {
          errorMessage = errorData.detail.message;
        } else if (typeof errorData.detail === 'object') {
          errorMessage = JSON.stringify(errorData.detail);
        }
      }
      
      throw new Error(errorMessage);
    }

    return response.json();
  }
}

export const authApi = new AuthAPI(); 