import React from 'react';
import { Navigate } from 'react-router-dom';
import AuthGuard from '../components/AuthGuard';
import { ProviderAccessGuard } from '../components/ProviderAccessGuard';
import { ExternalPage } from '../pages/ExternalPage';
import { EXTERNAL_APPS, getExternalAppUrl, FEATURES } from '../config';

/**
 * Generates dynamic routes for external applications
 * This allows for easy addition of new external apps without modifying the router
 */
export const generateExternalAppRoutes = () => {
  const routes: any[] = [];

  console.log('Generating external app routes...');
  console.log('EXTERNAL_APPS:', EXTERNAL_APPS);
  console.log('FEATURES.enableExternalServices:', FEATURES.enableExternalServices);

  Object.values(EXTERNAL_APPS).forEach(app => {
    console.log(`Processing app: ${app.id}, enabled: ${app.enabled}`);
    
    if (app.enabled && FEATURES.enableExternalServices) {
      // Main app route
      const mainRoute = {
        path: `/${app.id}`,
        element: (
          <AuthGuard>
            <ProviderAccessGuard>
              <ExternalPage url={getExternalAppUrl(app.id)} />
            </ProviderAccessGuard>
          </AuthGuard>
        ),
      };
      routes.push(mainRoute);
      console.log(`Added main route: /${app.id}`);

      // Sub-routes for each app (if defined)
      if (app.routes) {
        Object.entries(app.routes).forEach(([routeKey, routePath]) => {
          if (routeKey !== 'overview' && routePath !== '/') {
            const subRoute = {
              path: `/${app.id}${routePath}`,
              element: (
                <AuthGuard>
                  <ProviderAccessGuard>
                    <ExternalPage url={getExternalAppUrl(app.id, routeKey)} />
                  </ProviderAccessGuard>
                </AuthGuard>
              ),
            };
            routes.push(subRoute);
            console.log(`Added sub-route: /${app.id}${routePath}`);
          }
        });
      }
    } else {
      // Redirect disabled apps to home
      const redirectRoute = {
        path: `/${app.id}`,
        element: <Navigate to="/" replace />,
      };
      routes.push(redirectRoute);
      console.log(`Added redirect route for disabled app: /${app.id}`);
    }
  });

  console.log(`Generated ${routes.length} external app routes`);
  return routes;
};

/**
 * Get external app configuration for navigation
 */
export const getExternalAppNavConfig = () => {
  return Object.values(EXTERNAL_APPS)
    .filter(app => app.enabled && FEATURES.enableExternalServices)
    .map(app => ({
      id: app.id,
      name: app.name,
      path: `/${app.id}`,
      icon: app.icon,
      description: app.description,
      routes: app.routes
    }));
};

/**
 * Check if an external app is available
 */
export const isExternalAppAvailable = (appId: string): boolean => {
  const app = EXTERNAL_APPS[appId];
  return app ? app.enabled && FEATURES.enableExternalServices : false;
}; 