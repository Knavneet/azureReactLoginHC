import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider } from 'react-router-dom';
import { router } from './router';
import { Toaster } from 'react-hot-toast';
import './index.css';

// MSAL Imports
import { MsalProvider } from '@azure/msal-react';
import { msalInstance } from './lib/msal-config';

// Import and setup Axios interceptors for global error handling
import { setupAxiosInterceptors } from './lib/axios-interceptor';

// Import the ProviderProvider
import { ProviderProvider } from './contexts/ProviderContext';
import { NavigationProvider } from './contexts/NavigationContext';

// Initialize Axios interceptors
setupAxiosInterceptors();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <MsalProvider instance={msalInstance}>
      <ProviderProvider>
        <NavigationProvider>
          <RouterProvider router={router} />
          <Toaster position="top-right" />
        </NavigationProvider>
      </ProviderProvider>
    </MsalProvider>
  </StrictMode>
);