/**
 * Application configuration
 * 
 * This file centralizes all configuration values, including external URLs,
 * API endpoints, and other environment-specific settings.
 */

// Safe environment variable access for browser environments
const getEnv = (key: string, defaultValue: string): string => {
  // Check if import.meta.env is available (Vite) - PRIORITIZE .env file
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
    console.log(`🔧 ${key}: Using import.meta.env (.env file) = ${import.meta.env[key]}`);
    return import.meta.env[key];
  }
  
  // Check if process.env is available (Node.js / webpack)
  if (typeof process !== 'undefined' && process.env && process.env[key]) {
    console.log(`🔧 ${key}: Using process.env = ${process.env[key]}`);
    return process.env[key];
  }
  
  // Check if window.__ENV is available (for runtime environment variables) - LOWER PRIORITY
  if (typeof window !== 'undefined' && window.__ENV && window.__ENV[key]) {
    console.log(`🔧 ${key}: Using window.__ENV (env-config.js) = ${window.__ENV[key]}`);
    return window.__ENV[key];
  }
  
  // Fallback to default value
  console.log(`🔧 ${key}: Using default value = ${defaultValue}`);
  return defaultValue;
};

// Add TypeScript interface for window.__ENV
declare global {
  interface Window {
    __ENV?: Record<string, string>;
  }
}

// API URLs
export const API_BASE_URL = getEnv('REACT_APP_API_BASE_URL', 'http://localhost:8000');

// Azure AD Configuration
export const AZURE_AD_CLIENT_ID = getEnv('VITE_AZURE_AD_CLIENT_ID', '');
export const AZURE_AD_TENANT_ID = getEnv('VITE_AZURE_AD_TENANT_ID', '');
export const AZURE_AD_REDIRECT_URI = getEnv('VITE_AZURE_AD_REDIRECT_URI', 'http://localhost:5173');
export const API_URL = getEnv('REACT_APP_API_URL', 'http://localhost:8000');
export const CHAT_API_URL = getEnv('REACT_APP_CHAT_API_URL', 'http://localhost:8000/chat/');

// External Applications Configuration
export interface ExternalApp {
  id: string;
  name: string;
  baseUrl: string;
  description?: string;
  icon?: string;
  enabled: boolean;
  routes?: {
    [key: string]: string;
  };
}

// External Apps Configuration - Centralized and Docker-friendly
export const EXTERNAL_APPS: Record<string, ExternalApp> = {
  finops: {
    id: 'finops',
    name: 'FinOps',
    baseUrl: getEnv('REACT_APP_FINOPS_URL', 'https://finops.intelliops.cloud'),
    description: 'Financial Operations Management',
    icon: 'DollarSign',
    enabled: getEnv('REACT_APP_ENABLE_FINOPS', 'true') !== 'false',
    routes: {
      dashboard: '/',
      reports: '/reports',
      budgets: '/budgets',
      costs: '/costs'
    }
  },
  stack: {
    id: 'stack',
    name: 'Infrastructure Management',
    baseUrl: getEnv('REACT_APP_STACK_URL', 'https://stack.intelliops.cloud'),
    description: 'Infrastructure Stack Management',
    icon: 'Server',
    enabled: getEnv('REACT_APP_ENABLE_STACK', 'true') !== 'false',
    routes: {
      overview: '/',
      compute: '/compute',
      storage: '/storage',
      network: '/network',
      containers: '/containers',
      config: '/config'
    }
  },
  // Example of how to add more external apps
  monitoring: {
    id: 'monitoring',
    name: 'Monitoring',
    baseUrl: getEnv('REACT_APP_MONITORING_URL', 'https://monitoring.intelliops.cloud'),
    description: 'System Monitoring and Alerting',
    icon: 'Activity',
    enabled: getEnv('REACT_APP_ENABLE_MONITORING', 'false') !== 'false',
    routes: {
      dashboard: '/',
      alerts: '/alerts',
      metrics: '/metrics',
      logs: '/logs'
    }
  },
  security: {
    id: 'security',
    name: 'Security Center',
    baseUrl: getEnv('REACT_APP_SECURITY_URL', 'https://security.intelliops.cloud'),
    description: 'Security Management and Compliance',
    icon: 'Shield',
    enabled: getEnv('REACT_APP_ENABLE_SECURITY', 'false') !== 'false',
    routes: {
      dashboard: '/',
      vulnerabilities: '/vulnerabilities',
      compliance: '/compliance',
      policies: '/policies'
    }
  },
  // Example: Adding a new external app
  analytics: {
    id: 'analytics',
    name: 'Analytics Dashboard',
    baseUrl: getEnv('REACT_APP_ANALYTICS_URL', 'https://analytics.intelliops.cloud'),
    description: 'Business Intelligence and Analytics',
    icon: 'BarChart3',
    enabled: getEnv('REACT_APP_ENABLE_ANALYTICS', 'false') !== 'false',
    routes: {
      dashboard: '/',
      reports: '/reports',
      insights: '/insights',
      metrics: '/metrics'
    }
  }
};

// Helper functions for external apps
export const getExternalApp = (appId: string): ExternalApp | undefined => {
  return EXTERNAL_APPS[appId];
};

export const getEnabledExternalApps = (): ExternalApp[] => {
  return Object.values(EXTERNAL_APPS).filter(app => app.enabled);
};

export const getExternalAppUrl = (appId: string, route: string = '/'): string => {
  const app = getExternalApp(appId);
  if (!app) {
    throw new Error(`External app '${appId}' not found`);
  }
  
  // If route is defined in app routes, use it; otherwise use the provided route
  const finalRoute = app.routes?.[route] || route;
  return `${app.baseUrl}${finalRoute}`;
};

// Backward compatibility - these will be deprecated
export const STACK_BASE_URL = EXTERNAL_APPS.stack.baseUrl;
export const FINOPS_BASE_URL = EXTERNAL_APPS.finops.baseUrl;

// Infrastructure service URLs (backward compatibility)
export const INFRASTRUCTURE_URLS = {
  overview: getExternalAppUrl('stack', 'overview'),
  compute: getExternalAppUrl('stack', 'compute'),
  storage: getExternalAppUrl('stack', 'storage'),
  network: getExternalAppUrl('stack', 'network'),
  containers: getExternalAppUrl('stack', 'containers'),
  config: getExternalAppUrl('stack', 'config'),
};

// API configuration
export const API_CONFIG = {
  baseUrl: API_URL,
  timeout: parseInt(getEnv('REACT_APP_API_TIMEOUT', '30000')),
  retryAttempts: parseInt(getEnv('REACT_APP_API_RETRY_ATTEMPTS', '3')),
};

// Default provider
export const DEFAULT_PROVIDER = getEnv('REACT_APP_DEFAULT_PROVIDER', 'aws');

// Feature flags
export const FEATURES = {
  // External Apps (iframe apps)
  enableExternalServices: getEnv('REACT_APP_ENABLE_EXTERNAL_SERVICES', 'true') !== 'false',
  enableFinOps: EXTERNAL_APPS.finops.enabled,
  enableStack: EXTERNAL_APPS.stack.enabled,
  enableMonitoring: EXTERNAL_APPS.monitoring.enabled,
  enableAnalytics: EXTERNAL_APPS.analytics.enabled,
  // Internal page feature flags
  enableReports: getEnv('REACT_APP_ENABLE_REPORTS', 'true') !== 'false',
  enableNotifications: getEnv('REACT_APP_ENABLE_NOTIFICATIONS', 'true') !== 'false',
  enableSecurityPage: getEnv('REACT_APP_ENABLE_SECURITY_PAGE', 'true') !== 'false',
  enableLogs: getEnv('REACT_APP_ENABLE_LOGS', 'true') !== 'false',
  enableSettings: getEnv('REACT_APP_ENABLE_SETTINGS', 'true') !== 'false',
  enablePromptLibrary: getEnv('REACT_APP_ENABLE_PROMPT_LIBRARY', 'true') !== 'false',
  enableUserManagement: getEnv('REACT_APP_ENABLE_USER_MANAGEMENT', 'true') !== 'false',
};
