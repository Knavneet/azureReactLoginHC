import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { authService } from '../lib/auth-service';
import { User } from '../types';

interface AuthGuardProps {
  children: React.ReactNode;
  adminOnly?: boolean;
}

const AuthGuard: React.FC<AuthGuardProps> = ({ children, adminOnly = false }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if user is authenticated by trying to refresh session
        const userData = await authService.refreshSession();
        
        if (userData && userData.is_authenticated) {
          setIsAuthenticated(true);
          setUser(userData);
        } else {
          setIsAuthenticated(false);
          setUser(null);
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        setIsAuthenticated(false);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Listen for JWT expiration events
  useEffect(() => {
    const handleJWTExpired = () => {
      console.log('JWT expired event received in AuthGuard');
      setIsAuthenticated(false);
      setUser(null);
    };

    window.addEventListener('jwt-expired', handleJWTExpired);
    return () => window.removeEventListener('jwt-expired', handleJWTExpired);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    // Save the attempted location for redirect after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If admin access is required but user is not admin, redirect to chat
  if (adminOnly && user && !user.is_admin) {
    console.log('[AuthGuard] Admin access required but user is not admin, redirecting to chat');
    return <Navigate to="/chat" />;
  }
  
  // Special case for RBAC page - always requires admin access
  if (location.pathname === '/rbac' && user && !user.is_admin) {
    console.log('[AuthGuard] RBAC page requires admin access, redirecting to chat');
    return <Navigate to="/chat" />;
  }

  return <>{children}</>;
};

export default AuthGuard;