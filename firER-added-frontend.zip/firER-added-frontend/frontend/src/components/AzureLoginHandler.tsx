import { useEffect, useState } from 'react';
import { useMsal, useIsAuthenticated } from '@azure/msal-react';
import { useNavigate } from 'react-router-dom';
import { InteractionStatus } from '@azure/msal-browser';
import { loginRequest } from '../lib/msal-config';
import axios from 'axios';
import toast from 'react-hot-toast';
import { authService } from '../lib/auth-service';

const AzureLoginHandler = () => {
  const navigate = useNavigate();
  const { instance, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const [status, setStatus] = useState('Finalizing login...');

  useEffect(() => {
    const exchangeTokenAndLogin = async () => {
      if (isAuthenticated && inProgress === InteractionStatus.None) {
        setStatus('Azure AD token validated. Establishing application session...');
        try {
          const account = instance.getAllAccounts()[0];
          if (!account) {
            throw new Error('No Azure AD account found. Please try logging in again.');
          }

          const response = await instance.acquireTokenSilent({
            ...loginRequest,
            account: account,
          });

          // --- THIS IS THE IMPORTANT PART ---
          console.log('!!! STEP 1: About to send Azure ID Token to backend at /api/azure-auth/get_token');

          await axios.post('/api/azure-auth/get_token', {},
          {
            headers: {
              'Authorization': `Bearer ${response.idToken}`
            }
          });

          console.log('!!! STEP 2: Backend request to /api/azure-auth/get_token finished.');
          // --- END OF IMPORTANT PART ---

          setStatus('Application session created. Verifying user...');

          const user = await authService.refreshSession();

          if (user && user.is_authenticated) {
            setStatus('Login successful! Redirecting...');
            toast.success('Successfully logged in with Azure AD!');
            navigate('/chat');
          } else {
            throw new Error('Failed to verify application session after Azure AD login.');
          }

        } catch (error: any) {
          console.error('!!! ERROR in AzureLoginHandler:', error);
          setStatus(`Error: ${error.message || 'An unexpected error occurred.'} Please try again.`);
          toast.error('Failed to log in. Please try again.');
          setTimeout(() => navigate('/login'), 3000);
        }
      }
    };

    exchangeTokenAndLogin();

  }, [isAuthenticated, inProgress, instance, navigate]);

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h2>Login in progress...</h2>
      <p>{status}</p>
    </div>
  );
};

export default AzureLoginHandler;
