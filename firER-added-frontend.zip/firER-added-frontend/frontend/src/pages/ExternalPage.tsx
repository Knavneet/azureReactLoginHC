import { useState, useEffect } from 'react';
import { AppLayout } from '../components/AppLayout';
import { NavigationProvider } from '../contexts/NavigationContext';
import { EXTERNAL_APPS } from '../config';
import { isValidIframeUrl, IFRAME_SECURITY_CONFIGS } from '../utils/security';

interface ExternalPageProps {
  url?: string;
}

export function ExternalPage({ url = 'https://example.com' }: ExternalPageProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [urlIsValid, setUrlIsValid] = useState(false);

  useEffect(() => {
    setUrlIsValid(isValidIframeUrl(url));
  }, [url]);

  // Determine page subtitle based on URL - dynamically from external apps config
  const getSubtitle = () => {
    // Find which external app this URL belongs to
    const matchingApp = Object.values(EXTERNAL_APPS).find(app => {
      try {
        const appUrl = new URL(app.baseUrl);
        const currentUrl = new URL(url);
        return appUrl.hostname === currentUrl.hostname;
      } catch {
        return false;
      }
    });

    return matchingApp ? matchingApp.name : 'External Service';
  };

  // Function to reload the iframe content
  const reloadIframe = () => {
    setIsLoading(true);
    // Simulate iframe reload
    setTimeout(() => setIsLoading(false), 1000);
  };

  // If URL is not valid, show error
  if (!urlIsValid) {
    return (
      <NavigationProvider>
        <AppLayout>
          <div className="flex flex-col h-full w-full">
            <div className="flex-1 overflow-hidden bg-gray-50 flex items-center justify-center">
              <div className="text-center">
                <div className="text-red-600 text-xl mb-2">⚠️ Security Error</div>
                <div className="text-gray-700">
                  The requested URL is not allowed for security reasons.
                </div>
                <div className="text-sm text-gray-500 mt-2">
                  Only trusted IntelliOps domains are permitted.
                </div>
                <div className="text-xs text-gray-400 mt-4">
                  URL: {url}
                </div>
              </div>
            </div>
          </div>
        </AppLayout>
      </NavigationProvider>
    );
  }

  const securityConfig = IFRAME_SECURITY_CONFIGS.trusted;

  return (
    <NavigationProvider>
      <AppLayout>
        <div className="flex flex-col h-full w-full">
          {/* Header removed - no more subtitle or refresh button */}
          
          <div className="flex-1 overflow-hidden bg-gray-50 flex flex-col">
            {/* External Content */}
            <div className="flex-1 w-full h-full relative">
              {isLoading && (
                <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center z-10">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              )}
              <iframe
                src={url}
                className="w-full h-full absolute inset-0 border-0"
                title={getSubtitle()}
                sandbox={securityConfig.sandbox}
                referrerPolicy={securityConfig.referrerPolicy}
                loading={securityConfig.loading}
              />
            </div>
          </div>
        </div>
      </AppLayout>
    </NavigationProvider>
  );
}
