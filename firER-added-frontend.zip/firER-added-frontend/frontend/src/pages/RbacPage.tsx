import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '../components/AppLayout';
import { Header } from '../components/Header';
import { Search, CheckCircle, XCircle, ToggleLeft, ToggleRight, UserPlus, X, Shield, User as UserIcon } from 'lucide-react';
import { authService } from '../lib/auth-service';
import { API_BASE_URL } from '../config';

// Define the CloudProvider type
type CloudProvider = 'aws' | 'azure' | 'gcp' | 'onprem';

// Define interfaces
interface User {
  id: string;
  name: string;
  email: string;
  isAdmin: boolean;
}

interface UserAccess {
  id: string;
  userId: string;
  userName: string;
  email: string;
  isAdmin: boolean;
  isActive: boolean;
  providers: {
    aws: boolean;
    azure: boolean;
    gcp: boolean;
    onprem: boolean;
  };
}

// Define the super admin email
const SUPER_ADMIN_EMAIL = "admin@intelliops.com";

export function RbacPage() {
  // Helper function for authenticated API calls using httpOnly cookies
  const authenticatedFetch = async (url: string, options: RequestInit = {}) => {
    return fetch(url, {
      ...options,
      credentials: 'include', // Important: include cookies for authentication
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
  };

  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [userAccess, setUserAccess] = useState<UserAccess[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    isAdmin: false,
    providers: {
      aws: true,
      azure: false,
      gcp: false,
      onprem: false
    }
  });

  
  // Check if current user is admin
  useEffect(() => {
    try {
      // Use authService instead of localStorage
      if (!authService.isAuthenticated()) {
        navigate('/login');
        return;
      }
      
      const user = authService.getUser();
      if (!user) {
        navigate('/login');
        return;
      }
      
      if (!user.is_admin) {
        // Redirect non-admin users away from this page
        navigate('/chat');
        return;
      }
      
      // Load all users
      loadUsers();
    } catch (error) {
      console.error('Error loading user data:', error);
      navigate('/login');
    }
  }, [navigate]);
  
  const loadUsers = async () => {
    try {
      setIsLoading(true);
      
      // Fetch users from the backend API using httpOnly cookies
      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      const response = await authenticatedFetch(`${apiUrl}/api/users`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch users: ${response.statusText}`);
      }
      
      const usersData = await response.json();
      console.log('Loaded users from backend:', usersData);
      
      // Map backend users to our expected format
      const mappedUsers = usersData.map((user: any) => ({
        id: user.id.toString(),
        name: user.name || 'Unknown',
        email: user.email,
        isAdmin: user.is_admin || false
      }));
      
      setUsers(mappedUsers);
      
      // After loading users, load their access settings
      loadUserAccess(mappedUsers);
    } catch (error) {
      console.error('Error loading users:', error);
      setMessage({ type: 'error', text: 'Failed to load users' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const loadUserAccess = async (usersList: User[]) => {
    try {
      setIsLoading(true);
      
      // Now fetch provider access for all users
      const accessData: UserAccess[] = [];
      
      for (const user of usersList) {
        try {
          // Fetch provider access for this user using httpOnly cookies
          const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
          const response = await authenticatedFetch(`${apiUrl}/api/provider-access/user/${user.id}`);
          
          if (!response.ok) {
            console.warn(`Could not fetch provider access for user ${user.id}, creating default`);
            // Create default access settings for this user
            accessData.push({
              id: user.id,
              userId: user.id,
              userName: user.name,
              email: user.email,
              isAdmin: user.isAdmin,
              isActive: true, // Default to active
              providers: {
                aws: true,
                azure: false,
                gcp: false,
                onprem: false,
              }
            });
            continue;
          }
          
          const userAccess = await response.json();
          console.log(`Loaded access for user ${user.id}:`, userAccess);
          
          // Map backend provider access to our format
          const mappedAccess = {
            id: user.id,
            userId: user.id,
            userName: user.name,
            email: user.email,
            isAdmin: user.isAdmin,
            isActive: true,
            providers: {
              aws: userAccess.some((a: any) => a.provider === 'aws' && a.has_access) || false,
              azure: userAccess.some((a: any) => a.provider === 'azure' && a.has_access) || false,
              gcp: userAccess.some((a: any) => a.provider === 'gcp' && a.has_access) || false,
              onprem: userAccess.some((a: any) => a.provider === 'onprem' && a.has_access) || false,
            }
          };
          
          accessData.push(mappedAccess);
        } catch (error) {
          console.error(`Error loading access for user ${user.id}:`, error);
        }
      }
      
      setUserAccess(accessData);
    } catch (error) {
      console.error('Error loading user access:', error);
      setMessage({
        type: 'error',
        text: 'Failed to load user access data'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleUserActiveStatus = async (userId: string) => {
    try {
      const user = userAccess.find(u => u.userId === userId);
      if (!user) return;

      // Prevent disabling the super admin
      if (user.email === SUPER_ADMIN_EMAIL) {
        setMessage({
          type: 'error',
          text: 'Super admin cannot be deactivated'
        });
        return;
      }

      const newActiveStatus = !user.isActive;
      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      
      // Use the correct endpoint: PUT /api/users/{user_id}
      const response = await authenticatedFetch(`${apiUrl}/api/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify({
          is_active: newActiveStatus
        })
      });

      if (!response.ok) {
        throw new Error('Failed to toggle user status');
      }

      // Update local state
      setUserAccess(prev => prev.map(u => 
        u.userId === userId ? { ...u, isActive: newActiveStatus } : u
      ));

      setMessage({
        type: 'success',
        text: `User ${newActiveStatus ? 'activated' : 'deactivated'} successfully`
      });
    } catch (error) {
      console.error('Error toggling user status:', error);
      setMessage({
        type: 'error',
        text: 'Failed to update user status'
      });
    }
  };

  const toggleAdminStatus = async (userId: string) => {
    try {
      const user = userAccess.find(u => u.userId === userId);
      if (!user) return;

      // Prevent changing super admin status
      if (user.email === SUPER_ADMIN_EMAIL) {
        setMessage({
          type: 'error',
          text: 'Super admin status cannot be changed'
        });
        return;
      }

      const newAdminStatus = !user.isAdmin;
      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      
      // Use the correct endpoint: PUT /api/users/{user_id}
      const response = await authenticatedFetch(`${apiUrl}/api/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify({
          is_admin: newAdminStatus
        })
      });

      if (!response.ok) {
        throw new Error('Failed to toggle admin status');
      }

      // Update local state
      setUserAccess(prev => prev.map(u => 
        u.userId === userId ? { ...u, isAdmin: newAdminStatus } : u
      ));

      setMessage({
        type: 'success',
        text: `User ${newAdminStatus ? 'promoted to admin' : 'demoted to normal user'} successfully`
      });
    } catch (error) {
      console.error('Error toggling admin status:', error);
      setMessage({
        type: 'error',
        text: 'Failed to update admin status'
      });
    }
  };

  const saveProviderAccess = async (userId: string, provider: CloudProvider, hasAccess: boolean) => {
    try {
      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      
      const response = await authenticatedFetch(`${apiUrl}/api/provider-access/${provider}`, {
        method: 'PUT',
        body: JSON.stringify({
          user_id: parseInt(userId),
          has_access: hasAccess,
          is_active: true
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update provider access');
      }

      // Update local state
      setUserAccess(prev => prev.map(u => 
        u.userId === userId 
          ? { ...u, providers: { ...u.providers, [provider]: hasAccess } }
          : u
      ));

      setMessage({
        type: 'success',
        text: `${provider.toUpperCase()} access ${hasAccess ? 'granted' : 'revoked'} successfully`
      });
    } catch (error) {
      console.error('Error updating provider access:', error);
      setMessage({
        type: 'error',
        text: 'Failed to update provider access'
      });
    }
  };

  const handleCreateUser = async () => {
    try {
      if (!newUser.name || !newUser.email || !newUser.password) {
        setMessage({ type: 'error', text: 'Please fill in all required fields' });
        return;
      }

      const apiUrl = API_BASE_URL.endsWith('/') ? API_BASE_URL.slice(0, -1) : API_BASE_URL;
      
      // Create user
      const response = await authenticatedFetch(`${apiUrl}/api/users`, {
        method: 'POST',
        body: JSON.stringify({
          name: newUser.name,
          email: newUser.email,
          password: newUser.password,
          is_admin: newUser.isAdmin
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to create user');
      }

      const createdUser = await response.json();
      
      // Set provider access for the new user
      for (const [provider, hasAccess] of Object.entries(newUser.providers)) {
        if (hasAccess) {
          await authenticatedFetch(`${apiUrl}/api/provider-access/${provider}`, {
            method: 'PUT',
            body: JSON.stringify({
              user_id: createdUser.id,
              has_access: true,
              is_active: true
            })
          });
        }
      }

      setMessage({ type: 'success', text: 'User created successfully' });
      setShowCreateUser(false);
      setNewUser({
        name: '',
        email: '',
        password: '',
        isAdmin: false,
        providers: {
          aws: true,
          azure: false,
          gcp: false,
          onprem: false
        }
      });
      
      // Reload users
      loadUsers();
    } catch (error: any) {
      console.error('Error creating user:', error);
      setMessage({ type: 'error', text: error.message || 'Failed to create user' });
    }
  };

  const clearMessage = () => {
    setMessage({ type: '', text: '' });
  };

  // Filter users based on search term
  const filteredUserAccess = userAccess.filter(user =>
    user.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <div className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div className="px-4 py-6 sm:px-0">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-900">Role-Based Access Control</h1>
                <button
                  onClick={() => setShowCreateUser(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Create User
                </button>
              </div>

              {/* Message Display */}
              {message.text && (
                <div className={`mb-4 rounded-md p-4 ${
                  message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                }`}>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      {message.type === 'success' ? (
                        <CheckCircle className="h-5 w-5 text-green-400" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-400" />
                      )}
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium">{message.text}</p>
                    </div>
                    <div className="ml-auto pl-3">
                      <div className="-mx-1.5 -my-1.5">
                        <button
                          onClick={clearMessage}
                          className={`inline-flex rounded-md p-1.5 ${
                            message.type === 'success' 
                              ? 'text-green-500 hover:bg-green-100' 
                              : 'text-red-500 hover:bg-red-100'
                          } focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                            message.type === 'success' ? 'focus:ring-green-600' : 'focus:ring-red-600'
                          }`}
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Search */}
              <div className="mb-6">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              {/* Create User Modal */}
              {showCreateUser && (
                <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                  <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                    <div className="mt-3">
                      <h3 className="text-lg font-medium text-gray-900 mb-4">Create New User</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Name</label>
                          <input
                            type="text"
                            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            value={newUser.name}
                            onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Email</label>
                          <input
                            type="email"
                            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            value={newUser.email}
                            onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Password</label>
                          <input
                            type="password"
                            className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            value={newUser.password}
                            onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            checked={newUser.isAdmin}
                            onChange={(e) => setNewUser({ ...newUser, isAdmin: e.target.checked })}
                          />
                          <label className="ml-2 block text-sm text-gray-900">Admin User</label>
                        </div>
                        
                        {/* Provider Access Section */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Provider Access</label>
                          <div className="space-y-2">
                            {(['aws', 'azure', 'gcp', 'onprem'] as CloudProvider[]).map((provider) => (
                              <div key={provider} className="flex items-center">
                                <input
                                  type="checkbox"
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                  checked={newUser.providers[provider]}
                                  onChange={(e) => setNewUser({ 
                                    ...newUser, 
                                    providers: { 
                                      ...newUser.providers, 
                                      [provider]: e.target.checked 
                                    } 
                                  })}
                                />
                                <label className="ml-2 block text-sm text-gray-900 capitalize">
                                  {provider === 'onprem' ? 'On-Premises' : provider.toUpperCase()}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end space-x-3 mt-6">
                        <button
                          onClick={() => setShowCreateUser(false)}
                          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={handleCreateUser}
                          className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                          Create User
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Users Table */}
              {isLoading ? (
                <div className="text-center py-4">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <p className="mt-2 text-sm text-gray-500">Loading users...</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          User
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          AWS
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Azure
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          GCP
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          On-Prem
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredUserAccess.map((user) => (
                        <tr key={user.userId} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div>
                                <div className="text-sm font-medium text-gray-900">
                                  {user.userName}
                                  {user.isAdmin && (
                                    <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                      Admin
                                    </span>
                                  )}
                                </div>
                                <div className="text-sm text-gray-500">{user.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <button
                              onClick={() => toggleUserActiveStatus(user.userId)}
                              disabled={user.email === SUPER_ADMIN_EMAIL}
                              className={`inline-flex items-center ${
                                user.email === SUPER_ADMIN_EMAIL 
                                  ? 'cursor-not-allowed opacity-50' 
                                  : 'cursor-pointer hover:opacity-80'
                              }`}
                            >
                              {user.isActive ? (
                                <ToggleRight className="h-6 w-6 text-green-500" />
                              ) : (
                                <ToggleLeft className="h-6 w-6 text-gray-400" />
                              )}
                              <span className={`ml-2 text-sm ${
                                user.isActive ? 'text-green-600' : 'text-gray-500'
                              }`}>
                                {user.isActive ? 'Active' : 'Inactive'}
                              </span>
                            </button>
                          </td>
                          {(['aws', 'azure', 'gcp', 'onprem'] as CloudProvider[]).map((provider) => (
                            <td key={provider} className="px-6 py-4 whitespace-nowrap">
                              <button
                                onClick={() => saveProviderAccess(user.userId, provider, !user.providers[provider])}
                                className="inline-flex items-center p-2 rounded-md hover:bg-gray-100 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                                title={`Click to ${user.providers[provider] ? 'revoke' : 'grant'} ${provider.toUpperCase()} access`}
                              >
                                {user.providers[provider] ? (
                                  <CheckCircle className="h-6 w-6 text-green-500" />
                                ) : (
                                  <XCircle className="h-6 w-6 text-gray-300 hover:text-gray-400" />
                                )}
                              </button>
                            </td>
                          ))}
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => toggleAdminStatus(user.userId)}
                                disabled={user.email === SUPER_ADMIN_EMAIL}
                                className={`inline-flex items-center px-3 py-1 text-xs rounded-full font-medium transition-colors duration-200 ${
                                  user.email === SUPER_ADMIN_EMAIL 
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                                    : user.isAdmin 
                                      ? 'bg-orange-100 text-orange-700 hover:bg-orange-200' 
                                      : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                                }`}
                                title={user.email === SUPER_ADMIN_EMAIL ? 'Super admin cannot be modified' : `${user.isAdmin ? 'Demote to normal user' : 'Promote to admin'}`}
                              >
                                {user.isAdmin ? (
                                  <>
                                    <UserIcon className="h-3 w-3 mr-1" />
                                    Make Normal
                                  </>
                                ) : (
                                  <>
                                    <Shield className="h-3 w-3 mr-1" />
                                    Make Admin
                                  </>
                                )}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
