#!/usr/bin/env python3
"""
Script to check and fix provider access records for all users.
This ensures all users have proper provider access records in the database.
"""

import sys
import os

# Add the backend directory to the Python path
backend_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_dir)

from sqlalchemy.orm import Session
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text, DateTime, JSON, UniqueConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import SessionLocal, engine, Base

# Define the models we need directly here to avoid import issues
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(128), nullable=False)
    is_admin = Column(Boolean, default=False)
    is_authenticated = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

class ProviderAccess(Base):
    __tablename__ = "provider_access"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    provider = Column(String(32), nullable=False)
    has_access = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Unique constraint to prevent duplicate user-provider assignments
    __table_args__ = (UniqueConstraint('user_id', 'provider', name='_user_provider_uc'),)

def setup_provider_access_for_user(db: Session, user_id: int, user_email: str):
    """Setup provider access for a specific user"""
    providers = ["aws", "azure", "gcp", "onprem"]
    
    print(f"\nChecking provider access for user {user_id} ({user_email}):")
    
    for provider in providers:
        existing_access = db.query(ProviderAccess).filter(
            ProviderAccess.user_id == user_id,
            ProviderAccess.provider == provider
        ).first()
        
        if not existing_access:
            # Create provider access record
            db_access = ProviderAccess(
                user_id=user_id,
                provider=provider,
                has_access=True,
                is_active=True
            )
            db.add(db_access)
            print(f"  ✓ Added {provider} access for user {user_id}")
        else:
            print(f"  - {provider} access already exists: has_access={existing_access.has_access}, is_active={existing_access.is_active}")
    
    db.commit()

def main():
    """Main function to fix provider access for all users"""
    print("Fixing provider access records for all users...")
    
    # Create database tables if they don't exist
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        # Get all users
        users = db.query(User).all()
        print(f"Found {len(users)} users in the database")
        
        for user in users:
            setup_provider_access_for_user(db, user.id, user.email)
        
        print("\n✅ Provider access fix completed successfully!")
        
        # Verify the fix by showing all provider access records
        print("\nCurrent provider access records:")
        all_access = db.query(ProviderAccess).all()
        for access in all_access:
            user = db.query(User).filter(User.id == access.user_id).first()
            user_email = user.email if user else "Unknown"
            print(f"  User {access.user_id} ({user_email}): {access.provider} - has_access={access.has_access}, is_active={access.is_active}")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    main() 