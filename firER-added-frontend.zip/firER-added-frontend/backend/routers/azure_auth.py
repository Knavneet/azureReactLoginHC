from fastapi import APIRouter, Depends, HTTPException, status, Response, Request
from fastapi_azure_auth.auth import SingleTenantAzureAuthorizationCodeBearer
from fastapi_azure_auth.exceptions import InvalidAuth
from fastapi_azure_auth.user import User as AzureAuthUser # Alias to avoid conflict with our models.User
from sqlalchemy.orm import Session
from ..database import get_db
from .. import crud, schemas, models
from ..config import AZURE_AD_TENANT_ID, AZURE_AD_CLIENT_ID, AZURE_AD_REDIRECT_URI, AZURE_AD_APP_ID_URI
from ..dependencies import create_access_token, get_current_user # Import existing token creation utility
import logging
import os
from datetime import timedelta

logger = logging.getLogger(__name__)

# Ensure all required environment variables are set
if not all([AZURE_AD_TENANT_ID, AZURE_AD_CLIENT_ID, AZURE_AD_REDIRECT_URI, AZURE_AD_APP_ID_URI]):
    logger.error("Missing one or more Azure AD configuration environment variables. Azure AD authentication may not function correctly.")

# Initialize SingleTenantAzureAuthorizationCodeBearer
azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
    tenant_id=AZURE_AD_TENANT_ID,
    app_client_id=AZURE_AD_CLIENT_ID,
    scopes={
        "openid": "User sign in",
        "profile": "User profile",
        # Add your custom API scope if defined, e.g.:
        # f"api://{AZURE_AD_CLIENT_ID}/user_impersonation": "Access the API as the user"
    },
    allow_guest_users=True,
)

router = APIRouter(
    prefix="/azure-auth",
    tags=["azure-auth"],
)

ACCESS_TOKEN_EXPIRE_MINUTES = 30 # Or load from config

@router.post("/get_token")
async def azure_ad_token(response: Response, db: Session = Depends(get_db), azure_claims_user: AzureAuthUser = Depends(azure_scheme)):
    """Receives the ID Token from the frontend after Azure AD authentication.
    Validates the token and logs in/provisions the user.
    """
    logger.info("Received request to /api/azure-auth/get_token")
    try:
        # The 'azure_claims_user' is now a User object from fastapi_azure_auth.user
        # We can access its attributes directly.
        logger.info(f"Token validated successfully. Claims User: {azure_claims_user.claims}")
        
        # Access claims from the .claims attribute of the AzureAuthUser object
        claims = azure_claims_user.claims

        user_email = claims.get("preferred_username") or claims.get("upn") or claims.get("email")
        azure_oid = claims.get("oid") # Object ID is the unique identifier for the user in Azure AD
        user_name = claims.get("name") or user_email.split('@')[0] if user_email else "Azure User"

        logger.info(f"Extracted user_email: {user_email}, azure_oid: {azure_oid}, user_name: {user_name}")

        if not user_email or not azure_oid:
            logger.warning("Could not find user email or OID in Azure AD claims.")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Could not find user email or OID in Azure AD claims")

        user = crud.get_user_by_azure_oid(db, azure_oid=azure_oid)
        logger.info(f"User lookup by OID ({azure_oid}): {user.email if user else 'Not found'}")

        if not user:
            user = crud.get_user_by_email(db, email=user_email)
            logger.info(f"User lookup by email ({user_email}): {user.email if user else 'Not found'}")
            if user:
                user.azure_oid = azure_oid
                db.add(user)
                db.commit()
                db.refresh(user)
                logger.info(f"Existing user {user.email} linked with Azure AD OID: {azure_oid}")
            else:
                user_in = schemas.UserCreate(
                    email=user_email,
                    password=os.urandom(16).hex(),
                    name=user_name,
                    is_admin=False
                )
                user = crud.create_user(db=db, user=user_in, azure_oid=azure_oid)
                logger.info(f"New Azure AD user created: {user.email} with OID: {azure_oid}")
        else:
            logger.info(f"Existing Azure AD user logged in: {user.email} with OID: {azure_oid}")

        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.email}, expires_delta=access_token_expires
        )
        
        is_development = os.getenv("ENVIRONMENT", "production").lower() in ["development", "dev", "local"]
        
        response.set_cookie(
            key="access_token",
            value=access_token,
            max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            path="/",  # Set cookie path to root to be available for all API routes
            httponly=True,
            secure=not is_development,
            samesite="lax",
        )
        
        return {
            "message": "Login successful",
            "user": {
                "id": user.id,
                "email": user.email,
                "name": user.name,
                "is_admin": user.is_admin,
                "is_authenticated": True
            }
        }

    except HTTPException:
        raise # Re-raise HTTPExceptions as they are already formatted
    except Exception as e:
        logger.error(f"An unexpected error occurred during Azure AD token processing: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred during Azure AD login.",
        )

@router.get("/logout")
async def azure_logout(response: Response):
    """Logs out the user by clearing the httpOnly cookie"""
    is_development = os.getenv("ENVIRONMENT", "production").lower() in ["development", "dev", "local"]
    
    response.delete_cookie(
        key="access_token",
        path="/", # Ensure the cookie is deleted from the root path
        httponly=True,
        secure=not is_development,
        samesite="lax",
    )
    return {"message": "Azure AD logout successful"}

async def get_current_azure_user(azure_claims: dict = Depends(azure_scheme), db: Session = Depends(get_db)) -> models.User:
    """Dependency to get the current user from Azure AD claims and database"""
    # The 'azure_claims' here is the AzureAuthUser object
    claims = azure_claims.claims # Get the actual claims dictionary
    azure_oid = claims.get("oid")
    if not azure_oid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Azure AD Object ID (oid) not found in token claims")
    
    user = crud.get_user_by_azure_oid(db, azure_oid=azure_oid)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found in database")
    
    return user

@router.get("/protected-azure-route")
async def protected_route(current_user: models.User = Depends(get_current_user)):
    return {"message": f"Hello, {current_user.name}! You are authenticated via your application session.", "user_email": current_user.email}