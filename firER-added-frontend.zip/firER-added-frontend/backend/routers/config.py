from fastapi import APIRouter, Depends
from typing import List
import logging

from ..config import provider_config
from ..dependencies import get_current_user
from .. import models

# Configure logger
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/config",
    tags=["Configuration"],
    responses={404: {"description": "Not found"}},
)

@router.get("/enabled-providers", response_model=List[str])
def get_enabled_providers(current_user: models.User = Depends(get_current_user)):
    """
    Get the list of enabled cloud providers for this application instance.
    This is configured via environment variables by the administrator.
    """
    enabled_providers = provider_config.get_enabled_providers_list()
    logger.info(f"Returning enabled providers for user {current_user.email}: {enabled_providers}")
    return enabled_providers

@router.get("/provider-status/{provider}")
def check_provider_status(provider: str, current_user: models.User = Depends(get_current_user)):
    """
    Check if a specific provider is enabled.
    """
    is_enabled = provider_config.is_provider_enabled(provider)
    logger.info(f"Provider {provider} status check for user {current_user.email}: {'enabled' if is_enabled else 'disabled'}")
    return {
        "provider": provider,
        "enabled": is_enabled
    } 