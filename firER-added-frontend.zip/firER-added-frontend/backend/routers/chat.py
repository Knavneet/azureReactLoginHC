# backend/routers/chat.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import uuid # For generating session IDs if needed
import httpx
import asyncio

# Use relative imports
from .. import models, schemas, crud
from ..database import get_db
from ..dependencies import get_current_active_user

router = APIRouter(
    prefix="/chat",
    tags=["chat"],
    dependencies=[Depends(get_current_active_user)], # Require authentication
    responses={404: {"description": "Not found"}},
)

async def call_ai_provider(user_message: str, history: list, provider: str = "aws", session_id: str = None):
    """
    Call the appropriate AI provider based on the provider parameter.
    """
    try:
        # Convert ChatHistory objects to dictionaries for JSON serialization
        history_dicts = []
        for item in history:
            if hasattr(item, 'dict'):  # Pydantic model
                history_dicts.append(item.dict())
            elif isinstance(item, dict):  # Already a dictionary
                history_dicts.append(item)
            else:  # Convert to dict manually
                history_dicts.append({"role": getattr(item, 'role', 'user'), "content": getattr(item, 'content', str(item))})
        
        # Determine the provider endpoint
        if provider == "gcp":
            endpoint = "http://localhost:8000/api/gcp-chat"
            payload = {
                "session_id": session_id,
                "new_message": {
                    "role": "user",
                    "parts": [{"text": user_message}]
                },
                "start_session": not history_dicts or len(history_dicts) == 0
            }
        else:  # Default to AWS
            endpoint = "http://localhost:8000/api/aws-bedrock/chat"
            payload = {
                "message": user_message,
                "session_id": session_id,
                "history": history_dicts
            }
        
        # Make the API call to the provider
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(endpoint, json=payload)
            
            if response.status_code == 200:
                data = response.json()
                return data.get("response", "No response from AI provider")
            else:
                error_text = response.text
                raise Exception(f"AI provider error ({response.status_code}): {error_text}")
                
    except Exception as e:
        # Log the error and return a fallback response
        print(f"Error calling AI provider {provider}: {str(e)}")
        return f"I apologize, but I'm currently experiencing technical difficulties. Please try again later. (Error: {str(e)})"

@router.post("/", response_model=schemas.ChatResponse)
async def handle_chat_message( # Mark as async if potential I/O bound operations (like LLM call)
    chat_request: schemas.ChatRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """
    Handles incoming chat messages, processes them, saves to database, and returns a response.
    Manages chat history and session ID using database storage.
    """
    session_id = chat_request.session_id or str(uuid.uuid4())
    user_message = chat_request.user_message
    history = chat_request.history
    provider = getattr(chat_request, 'provider', 'aws')  # Default to AWS if not specified

    # Find or create chat thread based on session_id
    chat_thread = None
    
    # Try to find existing thread by session_id (stored in title or a custom field)
    # For now, we'll use a simple approach: create a new thread for each new session
    if session_id:
        # Look for existing thread - we'll store session_id in the title for now
        # In a more robust implementation, you'd add a session_id field to the ChatThread model
        existing_threads = crud.get_chat_threads_for_user(db, user_id=current_user.id)
        chat_thread = next((t for t in existing_threads if session_id in (t.title or "")), None)
    
    # Create new thread if none exists
    if not chat_thread:
        # Generate a title from the user message
        title = user_message[:50] + ("..." if len(user_message) > 50 else "")
        
        # Determine provider from session_id or use the provided one
        thread_provider = provider
        if session_id and "-" in session_id:
            thread_provider = session_id.split("-")[0]
        
        thread_data = schemas.ChatThreadCreate(
            title=f"{title} ({session_id})",  # Include session_id in title for identification
            cloud_provider=thread_provider,
            user_id=current_user.id
        )
        chat_thread = crud.create_chat_thread(db=db, thread=thread_data)
    
    # Save user message to database
    user_message_data = schemas.ChatMessageCreate(
        thread_id=chat_thread.id,
        role="user",
        content=user_message
    )
    saved_user_message = crud.create_chat_message(db=db, message=user_message_data)

    # Call the appropriate AI provider
    try:
        assistant_response = await call_ai_provider(
            user_message=user_message,
            history=history,
            provider=provider,
            session_id=session_id
        )
    except Exception as e:
        # Fallback response if AI provider fails
        assistant_response = f"I apologize, but I'm currently experiencing technical difficulties. Please try again later. (Error: {str(e)})"

    # Save assistant response to database
    assistant_message_data = schemas.ChatMessageCreate(
        thread_id=chat_thread.id,
        role="assistant",
        content=assistant_response
    )
    saved_assistant_message = crud.create_chat_message(db=db, message=assistant_message_data)

    # Construct the response
    response = schemas.ChatResponse(
        session_id=session_id,
        response=assistant_response
    )

    return response

@router.get("/threads/{thread_id}/messages", response_model=List[schemas.ChatMessage])
async def get_thread_messages(
    thread_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """
    Get all messages for a specific chat thread.
    """
    # Verify thread belongs to current user
    chat_thread = crud.get_chat_thread(db, thread_id=thread_id, user_id=current_user.id)
    if not chat_thread:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Chat thread with id {thread_id} not found"
        )
    
    # Get messages for the thread
    messages = crud.get_chat_messages_for_thread(db, thread_id=thread_id)
    return messages

@router.get("/threads", response_model=List[schemas.ChatThread])
async def get_user_threads(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """
    Get all chat threads for the current user.
    """
    return crud.get_chat_threads_for_user(db, user_id=current_user.id, skip=skip, limit=limit)

@router.post("/threads", response_model=schemas.ChatThread)
async def create_new_thread(
    thread_data: schemas.ChatThreadBase,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """
    Create a new chat thread.
    """
    thread_create_data = schemas.ChatThreadCreate(
        **thread_data.dict(),
        user_id=current_user.id
    )
    return crud.create_chat_thread(db=db, thread=thread_create_data)
